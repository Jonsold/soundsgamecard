
import React, { useState, useEffect } from 'react';
import { CardData, AppView, UserProfile, LocationState, CardAffinity } from './types';
import { CARD_LIBRARY, DECK_SIZE, INITIAL_LOCATIONS, POINTS_WIN, POINTS_LOSS, POINTS_RETREAT, RANKS, AVATAR_OPTIONS, RANK_STYLES, AFFINITY_LIST } from './constants';
import BattleScreen from './components/BattleScreen';
import Card from './components/Card';
import AdminScreen from './components/AdminScreen';
import LoginScreen from './components/LoginScreen';
import ShopScreen from './components/ShopScreen';
import { playSound, playBackgroundMusic, SoundKey } from './services/audioService'; // Import Audio Service

// Firebase Imports
import { auth, db } from './services/firebase';

const ADMIN_EMAIL = 'canalderespeito@gmail.com';

// --- DECK BUILDER COMPONENT ---
interface DeckBuilderProps {
  profile: UserProfile;
  library: CardData[];
  onBack: () => void;
  onSave: (deck: string[]) => Promise<void>;
}

const DeckBuilderScreen: React.FC<DeckBuilderProps> = ({ profile, library, onBack, onSave }) => {
  const [currentDeck, setCurrentDeck] = useState<string[]>(profile.currentDeck || []);
  const [isSaving, setIsSaving] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  // Helper to count occurrences in deck
  const getDeckCount = (cardId: string) => currentDeck.filter(id => id === cardId).length;
  
  // Helper to count owned copies
  const getOwnedCount = (cardId: string) => profile.collection.filter(id => id === cardId).length;

  const showFeedback = (msg: string) => {
      setFeedbackMsg(msg);
      playSound('ERROR');
      setTimeout(() => setFeedbackMsg(null), 3000);
  };

  const handleAddCard = (card: CardData) => {
    // 1. Check Deck Limit
    if (currentDeck.length >= DECK_SIZE) {
        showFeedback(`Deck Full! Remove a card to add ${card.name}.`);
        return;
    }
    
    // 2. Check Ownership Limit
    const owned = getOwnedCount(card.id);
    const used = getDeckCount(card.id);
    
    if (used >= owned) {
        showFeedback(`You only own ${owned} cop${owned === 1 ? 'y' : 'ies'} of this card.`);
        return;
    }

    playSound('CARD_SELECT');
    setCurrentDeck([...currentDeck, card.id]);
    setFeedbackMsg(null); // Clear error on success
  };

  const handleRemoveCard = (cardId: string) => {
    const index = currentDeck.indexOf(cardId);
    if (index > -1) {
      playSound('UI_CLICK');
      const newDeck = [...currentDeck];
      newDeck.splice(index, 1);
      setCurrentDeck(newDeck);
      setFeedbackMsg(null);
    }
  };

  const handleSave = async () => {
    if (currentDeck.length !== DECK_SIZE) {
       showFeedback(`Deck must have exactly ${DECK_SIZE} cards to save.`);
       return;
    }
    playSound('UI_CLICK');
    setIsSaving(true);
    await onSave(currentDeck);
    setIsSaving(false);
    onBack();
  };

  // Unique cards to display in collection (filtering only those user owns)
  const uniqueOwnedCards = Array.from(new Set(profile.collection))
    .map(id => library.find(c => c.id === id))
    .filter((c): c is CardData => !!c)
    .sort((a, b) => a.power_cost - b.power_cost);

  const isDeckFull = currentDeck.length >= DECK_SIZE;
  const averageCost = (currentDeck.reduce((acc, id) => acc + (library.find(c => c.id === id)?.power_cost || 0), 0) / (currentDeck.length || 1)).toFixed(1);

  return (
    <div className="h-[100dvh] w-screen bg-stone-950 flex flex-col text-stone-200 overflow-hidden bg-cover bg-center" style={{ backgroundImage: "url('https://res.cloudinary.com/dokkkdftz/image/upload/v1768619228/Hailuo_Image_com_base_nessa_imagem_sem_per_468767438506885120_resvc1.jpg?q=80&w=2074&auto=format&fit=crop')" }}>
       <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-0"></div>
       
       {/* Feedback Toast */}
       {feedbackMsg && (
           <div className="absolute top-20 left-1/2 -translate-x-1/2 z-50 bg-red-900/90 border border-red-500 text-white px-6 py-3 rounded shadow-2xl animate-in zoom-in slide-in-from-top duration-300 font-bold text-center">
               ⚠️ {feedbackMsg}
           </div>
       )}

       {/* Header */}
       <div className="relative z-10 bg-stone-900 p-3 md:p-4 border-b border-stone-800 flex justify-between items-center shadow-lg shrink-0">
           <button onClick={() => { playSound('UI_CLICK'); onBack(); }} className="text-stone-400 hover:text-white uppercase font-bold text-xs tracking-widest flex items-center gap-2">
               <span>←</span> <span className="hidden md:inline">Return</span>
           </button>
           <div className="text-center">
               <h1 className="text-lg md:text-xl font-serif font-black text-amber-500 tracking-widest rustic-title">DECK FORGE</h1>
               <div className={`text-[10px] uppercase font-bold tracking-[0.3em] transition-colors duration-300 ${currentDeck.length === DECK_SIZE ? 'text-green-500' : 'text-red-400 animate-pulse'}`}>
                   {currentDeck.length} / {DECK_SIZE} Cards
               </div>
           </div>
           <button 
                onClick={handleSave} 
                disabled={isSaving || currentDeck.length !== DECK_SIZE}
                className={`
                    px-4 md:px-6 py-2 rounded-sm font-bold text-[10px] md:text-xs uppercase tracking-widest transition-all
                    ${currentDeck.length === DECK_SIZE ? 'bg-amber-700 hover:bg-amber-600 text-white shadow-[0_0_15px_rgba(245,158,11,0.4)]' : 'bg-stone-800 text-stone-500 cursor-not-allowed'}
                `}
            >
               {isSaving ? 'Saving...' : 'Save'}
           </button>
       </div>

       {/* MAIN RESPONSIVE CONTAINER */}
       <div className="relative z-10 flex-1 flex flex-col md:flex-row overflow-hidden">
           
           {/* 1. Collection View (Top on Mobile, Left on Desktop) */}
           <div className="flex-1 p-4 md:p-6 overflow-y-auto custom-scrollbar relative order-1 md:order-1">
                <h2 className="mb-4 md:mb-6 text-stone-500 font-bold uppercase tracking-widest text-xs border-b border-stone-800 pb-2 flex justify-between">
                    <span>Your Collection</span>
                    <span className="text-[10px] text-stone-600">Tap to Add</span>
                </h2>
                
                {/* Responsive Grid: 3 cols on mobile, up to 5 on desktop */}
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-6 pb-32 md:pb-20">
                    {uniqueOwnedCards.map(card => {
                        const owned = getOwnedCount(card.id);
                        const used = getDeckCount(card.id);
                        const available = owned - used;
                        const isMaxed = available === 0;
                        
                        // Visual State Logic
                        let opacityClass = "opacity-100";
                        let overlayText = null;

                        if (isMaxed) {
                            opacityClass = "opacity-40 grayscale";
                            overlayText = "MAX";
                        } else if (isDeckFull) {
                            opacityClass = "opacity-50 grayscale";
                            overlayText = "FULL";
                        }

                        return (
                            <div 
                                key={card.id} 
                                className={`group relative transition-all duration-300 transform ${opacityClass} ${!isMaxed && !isDeckFull ? 'hover:-translate-y-2 hover:z-10' : ''}`}
                            >
                                <div onClick={() => handleAddCard(card)} className={`cursor-pointer`}>
                                    <Card data={card} size="sm" isPlayable={false} disableGrayscale={true} />
                                    
                                    {/* Overlay for Status */}
                                    {overlayText && (
                                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-xl backdrop-blur-[1px] border border-stone-600">
                                            <span className="text-red-500 font-black text-[10px] md:text-xs tracking-widest bg-black/80 px-1 py-1 rounded border border-red-900/50 shadow-lg transform -rotate-12">
                                                {overlayText}
                                            </span>
                                        </div>
                                    )}
                                </div>
                                <div className={`absolute -top-1 -right-1 md:-top-2 md:-right-2 text-[8px] md:text-[10px] w-5 h-5 md:w-6 md:h-6 flex items-center justify-center rounded-full font-bold shadow-lg z-20 border ${used > 0 ? 'bg-amber-900 border-amber-500 text-amber-100' : 'bg-stone-900 border-stone-700 text-stone-400'}`}>
                                    {used}/{owned}
                                </div>
                            </div>
                        );
                    })}
                </div>
           </div>

           {/* 2. Current Deck View (Bottom on Mobile, Right on Desktop) */}
           <div className="
                order-2 md:order-2 
                w-full md:w-80 
                h-40 md:h-full 
                flex-shrink-0 
                bg-stone-900/95 md:bg-stone-900/90 
                border-t-2 md:border-t-0 md:border-l border-amber-900/30 md:border-stone-800 
                flex flex-col 
                shadow-[0_-5px_20px_rgba(0,0,0,0.5)] md:shadow-2xl 
                backdrop-blur-md z-20
           ">
               {/* Header of Deck Panel */}
               <div className="p-2 md:p-4 border-b border-stone-800 bg-black/20 shrink-0">
                    <h2 className="text-stone-400 font-bold uppercase tracking-widest text-[10px] md:text-xs flex justify-between items-center">
                        <span>Current Loadout</span>
                        <span className="text-[10px] text-amber-600 font-mono">Avg: {averageCost}</span>
                    </h2>
               </div>
               
               {/* Deck List Content */}
               <div className="flex-1 overflow-x-auto md:overflow-x-hidden md:overflow-y-auto p-2 md:p-2 custom-scrollbar">
                   
                   {currentDeck.length === 0 && (
                       <div className="h-full flex flex-col items-center justify-center text-stone-600 italic text-xs gap-2 p-4 text-center">
                           <span className="text-2xl opacity-20">🎴</span>
                           <span className="hidden md:inline">Select cards to build deck.</span>
                           <span className="md:hidden">Empty Deck</span>
                       </div>
                   )}

                   {/* Container: Horizontal Row on Mobile, Vertical Col on Desktop */}
                   <div className="flex flex-row md:flex-col gap-2 md:gap-2 h-full md:h-auto items-center md:items-stretch">
                       {currentDeck.map((id, index) => {
                           const card = library.find(c => c.id === id);
                           if (!card) return null;
                           return (
                               <div key={`${id}-${index}`} onClick={() => handleRemoveCard(id)} className="group relative cursor-pointer flex-shrink-0">
                                   
                                   {/* MOBILE CARD VIEW (Mini Portrait) */}
                                   <div className="md:hidden w-20 h-28 rounded-lg overflow-hidden border border-stone-700 relative shadow-lg">
                                       <img src={card.image_url} className="w-full h-full object-cover" />
                                       <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
                                       <div className="absolute bottom-1 left-1 font-bold text-white text-[9px] truncate w-16">{card.name}</div>
                                       <div className="absolute top-1 left-1 w-5 h-5 bg-black/60 rounded-full flex items-center justify-center text-[10px] text-amber-400 font-bold border border-white/10">{card.power_cost}</div>
                                       <div className="absolute top-0 right-0 bg-red-600 text-white w-6 h-6 flex items-center justify-center font-bold text-xs rounded-bl-lg opacity-0 group-hover:opacity-100 transition-opacity">✕</div>
                                   </div>

                                   {/* DESKTOP CARD VIEW (Detailed Row) */}
                                   <div className="hidden md:flex items-center gap-3 bg-black/40 p-2 rounded border border-stone-800 hover:bg-red-900/20 hover:border-red-500/50 transition-all animate-in slide-in-from-right-2 duration-300">
                                        <div className="w-10 h-10 rounded border border-stone-700 overflow-hidden flex-shrink-0 relative">
                                            <img src={card.image_url} className="w-full h-full object-cover" />
                                            <div className="absolute inset-0 bg-red-500/0 group-hover:bg-red-500/20 transition-colors"></div>
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="text-xs font-bold text-stone-300 truncate group-hover:text-red-300 transition-colors">{card.name}</div>
                                            <div className="text-[10px] text-stone-500 flex gap-2">
                                                <span className="text-blue-400 font-mono font-bold">Cost: {card.power_cost}</span>
                                                <span className="opacity-30">|</span>
                                                <span className="text-amber-600">{card.class.split('/')[0]}</span>
                                            </div>
                                        </div>
                                        <div className="w-6 h-6 flex items-center justify-center text-stone-600 group-hover:text-red-400 transition-colors bg-black/20 rounded-full group-hover:bg-red-950/50">✕</div>
                                   </div>

                               </div>
                           );
                       })}
                       {/* Spacer for Mobile scrolling */}
                       <div className="w-4 md:hidden flex-shrink-0"></div>
                   </div>
               </div>
           </div>

       </div>
    </div>
  );
};

// --- EDIT PROFILE MODAL ---
interface EditProfileModalProps {
    currentUser: UserProfile;
    onClose: () => void;
    onSave: (newName: string, newAvatarId: string, newAffinity: CardAffinity) => Promise<void>;
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ currentUser, onClose, onSave }) => {
    const [name, setName] = useState(currentUser.name);
    const [avatarId, setAvatarId] = useState(currentUser.avatarId);
    const [affinity, setAffinity] = useState<CardAffinity>(currentUser.mainAffinity);
    const [saving, setSaving] = useState(false);

    const handleSaveClick = async () => {
        playSound('UI_CLICK');
        setSaving(true);
        await onSave(name, avatarId, affinity);
        setSaving(false);
        onClose();
    };

    return (
        <div className="fixed inset-0 z-[200] bg-black/90 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-stone-900 border border-amber-900/50 w-full max-w-lg rounded-xl shadow-2xl relative flex flex-col max-h-[90vh] overflow-hidden">
                <div className="p-6 border-b border-stone-800 bg-black/40">
                     <h2 className="text-2xl font-serif font-bold text-amber-500 tracking-widest">EDIT PERSONA</h2>
                     <p className="text-xs text-stone-500 mt-1 uppercase tracking-wide">Customize your identity in the realm</p>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
                    {/* Name Section */}
                    <div>
                        <label className="block text-xs uppercase font-bold text-stone-400 mb-2 tracking-widest">Character Name</label>
                        <input 
                            type="text" 
                            value={name} 
                            onChange={(e) => setName(e.target.value)}
                            className="w-full bg-stone-950 border border-stone-700 rounded p-3 text-amber-100 focus:border-amber-500 outline-none font-serif tracking-wide"
                        />
                    </div>

                    {/* Affinity Section */}
                    <div>
                        <label className="block text-xs uppercase font-bold text-stone-400 mb-2 tracking-widest">Elemental Affinity</label>
                        <div className="grid grid-cols-3 gap-2">
                            {AFFINITY_LIST.map(aff => (
                                <button
                                    key={aff}
                                    onClick={() => { playSound('UI_HOVER'); setAffinity(aff); }}
                                    className={`
                                        px-2 py-2 rounded border text-[10px] font-bold uppercase tracking-wider transition-all
                                        ${affinity === aff ? 'bg-amber-900/50 border-amber-500 text-amber-100 shadow-[0_0_10px_rgba(245,158,11,0.3)]' : 'bg-stone-950 border-stone-800 text-stone-500 hover:border-stone-600'}
                                    `}
                                 >
                                    {aff}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Avatar Section */}
                    <div>
                         <label className="block text-xs uppercase font-bold text-stone-400 mb-3 tracking-widest">Choose Avatar</label>
                         <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
                             {AVATAR_OPTIONS.map(av => (
                                 <div 
                                    key={av.id}
                                    onClick={() => { playSound('UI_HOVER'); setAvatarId(av.id); }}
                                    className={`
                                        cursor-pointer aspect-square rounded-lg overflow-hidden border-2 transition-all relative group
                                        ${avatarId === av.id ? 'border-amber-500 scale-110 shadow-lg z-10' : 'border-stone-800 hover:border-stone-500 opacity-60 hover:opacity-100'}
                                    `}
                                 >
                                     <img src={av.url} className="w-full h-full object-cover" />
                                     {avatarId === av.id && <div className="absolute inset-0 ring-1 ring-inset ring-amber-400/50"></div>}
                                 </div>
                             ))}
                         </div>
                    </div>
                </div>

                <div className="p-6 border-t border-stone-800 bg-stone-950/50 flex gap-4">
                    <button 
                        onClick={() => { playSound('UI_CLICK'); onClose(); }}
                        disabled={saving}
                        className="flex-1 py-3 border border-stone-700 text-stone-400 font-bold uppercase tracking-widest text-xs hover:text-white hover:bg-stone-800 rounded transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={handleSaveClick}
                        disabled={saving}
                        className="flex-1 py-3 bg-amber-700 text-amber-100 font-bold uppercase tracking-widest text-xs hover:bg-amber-600 border border-amber-600 shadow-lg rounded transition-colors flex items-center justify-center gap-2"
                    >
                        {saving ? 'Updating...' : 'Save Changes'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default function App() {
  const [view, setView] = useState<AppView>('LOGIN');
  const [loading, setLoading] = useState(true);
  
  // Initialize Global Data strictly with CARD_LIBRARY first to ensure they are visible
  const [masterLibrary, setMasterLibrary] = useState<CardData[]>(CARD_LIBRARY);
  const [masterLocations, setMasterLocations] = useState<LocationState[]>(INITIAL_LOCATIONS);
  
  // Offline Mode State
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  
  // User Data from Firebase
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [newCardReward, setNewCardReward] = useState<CardData | null>(null);
  const [battleResultMsg, setBattleResultMsg] = useState<string | null>(null);
  
  // UI State
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // --- MUSIC MANAGER ---
  // Watches the current view and switches the background track appropriately
  useEffect(() => {
    // Only manage music if user has interacted (implicit via browser policy, handled by service)
    switch (view) {
        case 'BATTLE':
            // FIXED: Only use single battle theme as requested
            playBackgroundMusic('THEME_BATTLE', 0.12);
            break;
        case 'DECK_BUILDER':
            playBackgroundMusic('THEME_DECK', 0.12);
            break;
        case 'LOGIN':
        case 'HOME':
        case 'SHOP':
        case 'ADMIN':
            playBackgroundMusic('INTRO', 0.10);
            break;
    }
  }, [view]);

  // --- MUSIC INITIALIZATION ---
  useEffect(() => {
    // Browsers block audio until the user interacts. 
    // We add a one-time listener to the whole document to start music on the very first click/key.
    const startAudio = () => {
        // playBackgroundMusic('INTRO', 0.10); // Managed by the view effect now, but good to trigger context
        // This call ensures AudioContext is resumed if suspended
        playBackgroundMusic('INTRO', 0.10);

        // Remove listeners once activated
        document.removeEventListener('click', startAudio);
        document.removeEventListener('keydown', startAudio);
    };

    document.addEventListener('click', startAudio);
    document.addEventListener('keydown', startAudio);

    return () => {
        document.removeEventListener('click', startAudio);
        document.removeEventListener('keydown', startAudio);
    };
  }, []);

  // 1. Listen to Auth State
  useEffect(() => {
    // Safety Timeout
    const loadingTimeout = setTimeout(() => {
        if (loading) {
            console.warn("Auth connection timed out. Switching to offline/login mode.");
            setLoading(false);
        }
    }, 3000);

    const unsubscribe = auth.onAuthStateChanged((user) => {
      clearTimeout(loadingTimeout);
      if (user) {
        const userDocRef = db.collection("users").doc(user.uid);
        userDocRef.onSnapshot((docSnap) => {
          if (docSnap.exists) {
            setCurrentUser(docSnap.data() as UserProfile);
            // NOTE: Removed view redirect logic here to prevent kicking user out of SHOP when profile updates
          }
        }, (err) => {
             console.error("Profile fetch error:", err);
        });
      } else {
        setCurrentUser(null);
        setView('LOGIN');
      }
      setLoading(false);
    });
    return () => {
        unsubscribe();
        clearTimeout(loadingTimeout);
    };
  }, []);

  // 2. Handle Routing from Login -> Home (Once user is authenticated)
  useEffect(() => {
    if (currentUser && view === 'LOGIN') {
        setView('HOME');
    }
    // SECURITY: Force non-admins out of ADMIN view
    if (view === 'ADMIN' && auth.currentUser?.email !== ADMIN_EMAIL) {
        setView('HOME');
        playSound('ERROR');
    }
  }, [currentUser, view]);

  // 3. Listen to Global Config & STRICT MERGE
  useEffect(() => {
    const libRef = db.collection("game_config");
    
    const unsubscribe = libRef.onSnapshot((querySnapshot) => {
      let dbCards: CardData[] = [];
      let dbLocations: LocationState[] = [];
      let foundLib = false;

      querySnapshot.forEach((doc) => {
        if (doc.id === 'library') {
             const data = doc.data();
             if (data && data.cards && Array.isArray(data.cards)) {
                 dbCards = data.cards;
                 foundLib = true;
             }
        }
        if (doc.id === 'locations') {
             const data = doc.data();
             if (data && data.items && Array.isArray(data.items)) {
                 dbLocations = data.items;
             }
        }
      });

      // --- STRICT FILTERING STRATEGY (UPDATED) ---
      // We start with your official CARD_LIBRARY (Code).
      // We ONLY look at DB cards if their ID matches one of your official cards (e.g., to update stats/names).
      // We DO NOT append cards from the DB that are not in your constants file.
      
      const validIds = new Set(CARD_LIBRARY.map(c => c.id));
      const finalLibrary = CARD_LIBRARY.map(officialCard => {
          // Check if there is an updated version in the DB
          const dbVersion = dbCards.find(c => c.id === officialCard.id);
          if (dbVersion) {
              // Return the DB version (it might have updated stats via Admin)
              return dbVersion;
          }
          // Otherwise keep the code version
          return officialCard;
      });

      // NOTE: We are intentionally NOT doing `finalLibrary.push(...)`. 
      // This ensures old junk cards in the DB are ignored.
      setMasterLibrary(finalLibrary);

      // --- STRICT MERGE FOR LOCATIONS (FIXED) ---
      // Changed from mapping dbLocations (which might be incomplete) to mapping INITIAL_LOCATIONS (the master list).
      // This ensures all 11 locations appear immediately. We merge DB data (names/descriptions) if available.
      
      const mergedLocations = INITIAL_LOCATIONS.map(codeLoc => {
          const dbLoc = dbLocations.find(l => l.id === codeLoc.id);
          if (dbLoc) {
              return { 
                  ...dbLoc, 
                  imageUrl: codeLoc.imageUrl, // Prioritize code image to ensure visual updates
                  id: codeLoc.id 
              };
          }
          // No DB entry? Use code default entirely.
          return codeLoc;
      });
      
      setMasterLocations(mergedLocations);
      
      setIsOfflineMode(!foundLib);
      
    }, (error) => {
        console.warn("Using local configuration due to connection error:", error.message);
        // Fallback to purely local constants
        setMasterLibrary(CARD_LIBRARY);
        setMasterLocations(INITIAL_LOCATIONS);
        setIsOfflineMode(true);
    });

    return unsubscribe;
  }, []);

  // --- ACTIONS ---

  const handleLogout = async () => {
      playSound('UI_CLICK');
      await auth.signOut();
  };

  const calculateNewRank = (currentPoints: number): number => {
      if (currentPoints >= 2000) return 6;
      if (currentPoints >= 1000) return 5;
      if (currentPoints >= 600) return 4;
      if (currentPoints >= 300) return 3;
      if (currentPoints >= 100) return 2;
      return 1;
  };

  const handleBattleEnd = async (winner: boolean, retreated: boolean, capturedCards?: CardData[]) => {
    if (!currentUser || !auth.currentUser) return;

    const userDocRef = db.collection("users").doc(auth.currentUser.uid);
    let update: Partial<UserProfile> = {};
    let msg = "";

    if (retreated) {
        const newPoints = Math.max(0, currentUser.points - POINTS_RETREAT);
        update = { 
            losses: currentUser.losses + 1,
            points: newPoints
        };
        msg = `You fled the battlefield! -${POINTS_RETREAT} Honor Points.`;
    } else if (winner) {
        // REWARD LOGIC: Try to pick from captured cards first
        let rewardCard: CardData;
        
        if (capturedCards && capturedCards.length > 0) {
             rewardCard = capturedCards[Math.floor(Math.random() * capturedCards.length)];
        } else {
             // Fallback if opponent played nothing (rare)
             rewardCard = masterLibrary[Math.floor(Math.random() * masterLibrary.length)];
        }

        const newPoints = currentUser.points + POINTS_WIN;
        const newLevel = calculateNewRank(newPoints);
        
        update = {
            wins: currentUser.wins + 1,
            level: newLevel,
            points: newPoints,
            collection: [...currentUser.collection, rewardCard.id]
        };
        setNewCardReward(rewardCard);
        msg = `Victory! +${POINTS_WIN} Points.`;
        if(newLevel > currentUser.level) msg += ` RANK PROMOTION: ${RANKS[newLevel]}!`;
    } else {
        const newPoints = Math.max(0, currentUser.points - POINTS_LOSS);
        update = { 
            losses: currentUser.losses + 1,
            points: newPoints
        };
        msg = `Defeat. -${POINTS_LOSS} Honor Points.`;
    }
    
    setBattleResultMsg(msg);
    setTimeout(() => setBattleResultMsg(null), 4000);

    try {
        await userDocRef.update(update);
    } catch (e) {
        console.error("Failed to save progress:", e);
        setBattleResultMsg("Connection lost. Progress saved locally.");
    }
    setView('HOME');
  };

  const updateDeck = async (newDeckIds: string[]) => {
      if (!auth.currentUser) return;
      try {
        const userDocRef = db.collection("users").doc(auth.currentUser.uid);
        await userDocRef.update({ currentDeck: newDeckIds });
      } catch(e) { console.error("Update Deck Error", e); }
  };

  const handleUpdateLibrary = async (newLib: CardData[]): Promise<void> => {
      await db.collection("game_config").doc("library").set({ cards: newLib });
  };

  const handleUpdateLocations = async (newLocs: LocationState[]): Promise<void> => {
      await db.collection("game_config").doc("locations").set({ items: newLocs });
  };
  
  const handleUpdateProfile = async (newName: string, newAvatarId: string, newAffinity: CardAffinity) => {
      if (!auth.currentUser) return;
      try {
          await db.collection("users").doc(auth.currentUser.uid).update({
              name: newName,
              avatarId: newAvatarId,
              mainAffinity: newAffinity
          });
      } catch (e) {
          console.error("Profile update error", e);
          alert("Could not update profile.");
      }
  };

  if (loading) return <div className="h-[100dvh] w-screen bg-stone-950 flex items-center justify-center text-amber-500 font-serif animate-pulse">CONNECTING TO REALM...</div>;

  if (view === 'LOGIN') return <LoginScreen onLogin={() => setView('HOME')} />;

  if (!currentUser) return <LoginScreen onLogin={() => setView('HOME')} />;

  // Validate avatar exists, fallback to first if not
  const userAvatarUrl = AVATAR_OPTIONS.find(a => a.id === currentUser.avatarId)?.url || AVATAR_OPTIONS[0].url;

  if (view === 'ADMIN') {
      return (
          <AdminScreen 
            library={masterLibrary}
            locations={masterLocations}
            onUpdateLibrary={handleUpdateLibrary}
            onUpdateLocations={handleUpdateLocations}
            onResetAll={async () => { 
                if(confirm("Reset Global DB with Local Defaults?")) { 
                    await db.collection("game_config").doc("library").set({ cards: CARD_LIBRARY }); 
                    await db.collection("game_config").doc("locations").set({ items: INITIAL_LOCATIONS }); 
                } 
            }}
            onBack={() => { playSound('UI_CLICK'); setView('HOME'); }}
          />
      );
  }

  if (view === 'SHOP') {
      return (
          <ShopScreen 
            library={masterLibrary}
            profile={currentUser}
            onBack={() => { playSound('UI_CLICK'); setView('HOME'); }}
          />
      );
  }

  if (view === 'BATTLE') {
      return (
          <BattleScreen 
            // Ensure we only show deck cards that actually exist in the master library
            playerDeckData={masterLibrary.filter(c => currentUser.currentDeck.includes(c.id))}
            fullLibrary={masterLibrary}
            initialLocations={masterLocations}
            onGameEnd={handleBattleEnd}
            onBack={() => { playSound('UI_CLICK'); setView('HOME'); }}
          />
      );
  }

  if (view === 'DECK_BUILDER') {
      return (
          <DeckBuilderScreen 
            profile={currentUser} 
            library={masterLibrary}
            onBack={() => { playSound('UI_CLICK'); setView('HOME'); }}
            onSave={updateDeck}
          />
      );
  }

  const rankStyle = RANK_STYLES[currentUser.level] || RANK_STYLES[1];

  return (
    <div 
        className="h-[100dvh] w-screen bg-stone-950 text-stone-200 flex flex-col font-sans overflow-y-auto bg-cover bg-center bg-fixed relative"
        style={{ backgroundImage: "url('https://res.cloudinary.com/dokkkdftz/image/upload/v1768619228/Hailuo_Image_com_base_nessa_imagem_sem_per_468767438506885120_resvc1.jpg?q=80&w=2074&auto=format&fit=crop')" }}
    >
        {/* Dark Overlay for better contrast */}
        <div className="fixed inset-0 bg-black/60 pointer-events-none z-0"></div>

        {isEditingProfile && (
            <EditProfileModal 
                currentUser={currentUser}
                onClose={() => setIsEditingProfile(false)}
                onSave={handleUpdateProfile}
            />
        )}

        {newCardReward && (
            <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
                <div className="bg-stone-900/95 p-10 rounded-xl border-2 border-amber-600/50 flex flex-col items-center max-w-lg w-full text-center shadow-[0_0_100px_rgba(245,158,11,0.2)] relative overflow-hidden">
                    {/* Background ambient light */}
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.1)_0%,transparent_70%)] pointer-events-none"></div>
                    
                    <h2 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-amber-300 to-amber-600 mb-2 tracking-widest rustic-title drop-shadow-sm uppercase relative z-10">
                        SPOILS OF WAR
                    </h2>
                    <div className="w-24 h-1 bg-amber-600/50 mb-8 rounded-full"></div>

                    {/* Card Container - No scaling hacks, used Size LG */}
                    <div className="mb-8 relative z-10 filter drop-shadow-2xl hover:scale-105 transition-transform duration-500">
                        <div className="absolute inset-0 bg-amber-500/20 blur-xl rounded-full"></div>
                        <Card data={newCardReward} isPlayable={false} size="lg" disableGrayscale={true} />
                    </div>
                    
                    <p className="mb-8 text-amber-100/80 font-serif italic tracking-wide text-lg relative z-10">
                        "You have claimed a new soul for your deck."
                    </p>
                    
                    <button 
                        onClick={() => { playSound('COINS'); setNewCardReward(null); }} 
                        className="relative z-10 bg-gradient-to-r from-amber-700 to-amber-900 hover:from-amber-600 hover:to-amber-800 text-amber-100 border-t border-amber-500/50 font-bold px-12 py-4 rounded shadow-xl hover:shadow-[0_0_30px_rgba(245,158,11,0.4)] transition-all uppercase tracking-[0.2em] transform active:scale-95"
                    >
                        CLAIM LOOT
                    </button>
                </div>
            </div>
        )}

        {battleResultMsg && !newCardReward && (
             <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-stone-900 border border-amber-500/50 text-amber-100 px-8 py-4 rounded-lg z-[200] shadow-2xl animate-in zoom-in slide-in-from-top duration-500 text-center font-serif text-xl font-bold backdrop-blur-md">
                 {battleResultMsg}
             </div>
        )}

        {isOfflineMode && (
             <div className="fixed top-20 right-4 bg-amber-900/80 border border-amber-500/30 text-amber-200 px-3 py-1.5 rounded text-xs font-bold z-[50] flex items-center gap-2 backdrop-blur-sm animate-pulse">
                 <span>⚠️</span> Offline Mode: Using Backup Data
             </div>
        )}

        <div className="max-w-md mx-auto w-full p-6 flex flex-col gap-6 relative z-10">
            {/* TOP BAR */}
            <div className="flex items-center justify-between border-b border-stone-800 pb-4 bg-stone-950/50 p-4 rounded-lg backdrop-blur-sm">
                <h1 className="text-3xl md:text-4xl font-black tracking-[0.15em] text-transparent bg-clip-text bg-gradient-to-br from-amber-300 via-orange-500 to-amber-800 rustic-title drop-shadow-[0_0_15px_rgba(249,115,22,0.6)]">
                    SNAP BATTLES
                </h1>
                <button onClick={handleLogout} className="text-[10px] text-stone-400 hover:text-red-500 uppercase font-bold tracking-tighter transition-colors border border-stone-800 px-2 py-1 rounded hover:bg-stone-900">Exit Portal</button>
            </div>

            {/* MAIN PROFILE CARD - REDESIGNED */}
            <div className="bg-stone-900/80 border border-stone-700 rounded-xl p-0 shadow-2xl relative overflow-hidden group backdrop-blur-md">
                {/* Decorative Corners */}
                <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-amber-600/50"></div>
                <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-amber-600/50"></div>
                
                <div className="flex flex-col md:flex-row items-center gap-6 p-6 relative z-10">
                    
                    {/* HEXAGON AVATAR (Same as Battle) */}
                    <div className="relative w-24 h-24 md:w-28 md:h-28 flex-shrink-0">
                         <div className="w-full h-full bg-black flex items-center justify-center relative" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                            <div className={`absolute inset-0 z-0 opacity-50 ${rankStyle}`}></div>
                            <div className="absolute inset-[2px] bg-stone-900 flex items-center justify-center overflow-hidden z-10" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                                <img src={userAvatarUrl} className="w-full h-full object-cover" />
                            </div>
                            {/* Edit Avatar Overlay Hint */}
                            <div 
                                onClick={() => { playSound('UI_CLICK'); setIsEditingProfile(true); }}
                                className="absolute inset-0 z-20 flex items-center justify-center bg-black/50 opacity-0 hover:opacity-100 transition-opacity cursor-pointer"
                                style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}
                            >
                                <span className="text-[10px] font-bold uppercase tracking-widest text-white">Edit</span>
                            </div>
                         </div>
                         {/* Rank Orb */}
                         <div className={`absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold z-30 shadow-lg ${rankStyle}`}>
                            {currentUser.level}
                         </div>
                    </div>

                    {/* USER INFO */}
                    <div className="flex-1 text-center md:text-left">
                        <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
                            <h2 className="text-2xl font-bold text-amber-100 rustic-title tracking-wide">{currentUser.name}</h2>
                            <button onClick={() => { playSound('UI_CLICK'); setIsEditingProfile(true); }} className="text-stone-500 hover:text-amber-500 transition-colors text-xs" title="Edit Profile">✏️</button>
                        </div>
                        
                        <div className="text-xs text-amber-600 font-bold uppercase tracking-widest mb-3">{RANKS[currentUser.level]}</div>
                        
                        <div className="inline-flex items-center gap-2 bg-black/40 px-3 py-1 rounded border border-stone-800 hover:border-amber-700 cursor-pointer transition-colors" onClick={() => { playSound('UI_CLICK'); setIsEditingProfile(true); }}>
                            <span className="text-[10px] text-stone-500 uppercase tracking-widest">Affinity:</span>
                            <span className="text-xs font-bold text-stone-300">{currentUser.mainAffinity || 'Standard'}</span>
                        </div>
                    </div>
                </div>

                {/* STATS FOOTER */}
                <div className="flex gap-4 bg-black/40 border-t border-stone-800 py-4 relative z-10">
                    <div className="flex-1 text-center border-r border-stone-800">
                        <div className="text-xl font-bold text-stone-300 rustic-title">{currentUser.wins}</div>
                        <div className="text-[10px] uppercase tracking-widest text-stone-500">Wins</div>
                    </div>
                    <div className="flex-1 text-center border-r border-stone-800">
                         <div className="text-xl font-bold text-amber-500 rustic-title">{currentUser.points}</div>
                        <div className="text-[10px] uppercase tracking-widest text-amber-900/70">Points</div>
                    </div>
                    <div className="flex-1 text-center">
                         <div className="text-xl font-bold text-stone-400 rustic-title">{currentUser.collection.length}</div>
                        <div className="text-[10px] uppercase tracking-widest text-stone-600">Cards</div>
                    </div>
                </div>
            </div>

            {/* ACTION GRID */}
            <div className="grid gap-4">
                {/* NEW ORANGE BUTTON DESIGN */}
                <button onClick={() => { playSound('UI_CLICK'); setView('BATTLE'); }} className="h-24 bg-gradient-to-r from-amber-700 to-orange-800 border-2 border-amber-500 rounded-lg flex items-center justify-center gap-4 text-xl font-bold text-white shadow-[0_0_20px_rgba(245,158,11,0.3)] hover:shadow-[0_0_30px_rgba(245,158,11,0.6)] hover:border-amber-400 hover:scale-[1.02] transition-all backdrop-blur-sm group overflow-hidden relative">
                    <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                    <span className="text-3xl relative z-10">⚔️</span> 
                    <span className="rustic-title tracking-widest relative z-10">ENTER BATTLE</span>
                </button>
                
                <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => { playSound('UI_CLICK'); setView('DECK_BUILDER'); }} className="h-16 bg-stone-900/80 border border-stone-700 rounded-lg flex items-center justify-center gap-3 font-semibold text-stone-400 hover:text-amber-200 transition-colors backdrop-blur-sm shadow-lg">
                        <span>🎴</span> Deck <span className="text-xs opacity-50">({currentUser.currentDeck.length}/{DECK_SIZE})</span>
                    </button>
                    <button onClick={() => { playSound('UI_CLICK'); setView('SHOP'); }} className="h-16 bg-stone-900/80 border border-stone-700 rounded-lg flex items-center justify-center gap-3 font-semibold text-stone-400 hover:text-amber-200 transition-colors backdrop-blur-sm shadow-lg">
                        <span>💰</span> Merchant
                    </button>
                </div>
                
                {/* ADMIN BUTTON - STRICTLY RESTRICTED TO SPECIFIC EMAIL */}
                {auth.currentUser?.email === ADMIN_EMAIL && (
                    <button onClick={() => { playSound('UI_CLICK'); setView('ADMIN'); }} className="h-10 border border-dashed border-stone-800/50 bg-stone-950/30 rounded-lg flex items-center justify-center gap-2 text-xs text-stone-500 hover:text-stone-300 transition-colors">
                        <span>⚙️</span> Realm Administration
                    </button>
                )}
            </div>
        </div>
    </div>
  );
}
