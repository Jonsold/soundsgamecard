
import React, { useState, useEffect } from 'react';
import { CardData, CardClass, LocationState, CardAffinity } from '../types';
import Card from './Card';
import { CARD_LIBRARY, INITIAL_LOCATIONS } from '../constants'; // Import constants
import { playSound, playAudioFile, SOUND_MAP, VOICE_COLLECTION, SoundKey } from '../services/audioService'; // Import Audio Service
import { auth } from '../services/firebase';

interface AdminScreenProps {
  library: CardData[];
  locations: LocationState[];
  onUpdateLibrary: (newLibrary: CardData[]) => Promise<void>;
  onUpdateLocations: (newLocations: LocationState[]) => Promise<void>;
  onResetAll: () => void; // Prop for resetting all data
  onBack: () => void;
}

const INITIAL_FORM_STATE: CardData = {
  id: '',
  name: 'New Card',
  class: 'Human / Knight',
  affinity: 'Standard', // Default affinity
  power_cost: 1,
  stats: { atack: 1, defense: 1 },
  abilities: { on_attack: 'Strike', on_defense: 'Block' },
  image_url: 'https://picsum.photos/200/300'
};

const AVAILABLE_CLASSES: CardClass[] = [
  'Elf', 'Dwarf', 'Human / Knight', 'Orc / Warrior', 'Mage', 'Beast', 'Undead', 'Warrior', 'Human', 'Human Warrior', 'Monster Warrior', 'Dragon', 'Zombie'
];

const AVAILABLE_AFFINITIES: CardAffinity[] = [
    'Standard', 'Fire', 'Ice', 'Nature', 'Dark', 'Light', 'Earth', 'Wind', 'Electric', 'Toxic', 'Cosmic', 'Aquatic'
];

type AdminTab = 'CARDS' | 'LOCATIONS' | 'AUDIO';

const ADMIN_EMAIL = 'canalderespeito@gmail.com';

export default function AdminScreen({ library, locations, onUpdateLibrary, onUpdateLocations, onResetAll, onBack }: AdminScreenProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('CARDS');
  const [editingCard, setEditingCard] = useState<CardData | null>(null);
  const [editingLocation, setEditingLocation] = useState<LocationState | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false); // Estado para loading visual

  // Audio Diagnostic State
  const [audioStatuses, setAudioStatuses] = useState<Record<string, { status: string, details: string, path: string }>>({});
  const [isRunningDiag, setIsRunningDiag] = useState(false);

  // Form States
  const [cardFormData, setCardFormData] = useState<CardData>(INITIAL_FORM_STATE);
  const [locFormData, setLocFormData] = useState<LocationState | null>(null);

  // --- SECURITY CHECK ---
  useEffect(() => {
    if (auth.currentUser?.email !== ADMIN_EMAIL) {
        onBack();
    }
  }, []);

  const triggerSaveFeedback = () => {
    setShowSaveSuccess(true);
    setTimeout(() => setShowSaveSuccess(false), 2000);
  };
  
  // Function to explicitly import constants.ts data to DB
  const handleImportFromCode = async () => {
      if(confirm("DANGER: This will overwrite the entire database configuration with the permanent card list from the code. \n\nAre you ABSOLUTELY sure?")) {
          setIsSaving(true);
          try {
              await onUpdateLibrary(CARD_LIBRARY);
              await onUpdateLocations(INITIAL_LOCATIONS);
              triggerSaveFeedback();
          } catch(e) {
              alert("Failed to import from code.");
              console.error(e);
          } finally {
              setIsSaving(false);
          }
      }
  };

  // --- CARD LOGIC ---
  const handleEditCard = (card: CardData) => {
    setEditingCard(card);
    setCardFormData({ ...card, affinity: card.affinity || 'Standard' });
  };

  const handleCreateNewCard = () => {
    const newId = `custom_${Date.now()}`;
    setEditingCard({ ...INITIAL_FORM_STATE, id: newId });
    setCardFormData({ ...INITIAL_FORM_STATE, id: newId });
  };

  const handleDeleteCard = async (id: string) => {
    const cardName = library.find(c => c.id === id)?.name || "this card";
    if (confirm(`⚠️ WARNING: You are about to PERMANENTLY delete "${cardName}" (ID: ${id}) from the Firebase Database.\n\nThis cannot be undone. Are you sure?`)) {
        setIsSaving(true);
        const newLib = library.filter(c => c.id !== id);
        await onUpdateLibrary(newLib);
        if (editingCard?.id === id) {
            setEditingCard(null);
        }
        setIsSaving(false);
        triggerSaveFeedback();
    }
  };

  const handleSaveCard = async () => {
    if (!cardFormData.name || !cardFormData.image_url || !cardFormData.id) {
        alert("ID, Name and Image URL are required");
        return;
    }

    setIsSaving(true);

    try {
        let newLibrary = [...library];
        const originalId = editingCard?.id;
        const conflict = newLibrary.find(c => c.id === cardFormData.id && c.id !== originalId);
        if (conflict) {
             alert(`Cannot save: ID '${cardFormData.id}' is already taken by card "${conflict.name}".`);
             setIsSaving(false);
             return;
        }
        const originalIndex = newLibrary.findIndex(c => c.id === originalId);

        if (originalIndex >= 0) {
            newLibrary[originalIndex] = cardFormData;
        } else {
            newLibrary.push(cardFormData);
        }

        await onUpdateLibrary(newLibrary);
        setEditingCard(null);
        triggerSaveFeedback();
    } catch (error) {
        alert("Error saving card to database.");
        console.error(error);
    } finally {
        setIsSaving(false);
    }
  };

  const updateCardField = (field: keyof CardData, value: any) => {
    setCardFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateCardStats = (field: 'atack' | 'defense', value: number) => {
    setCardFormData(prev => ({
        ...prev,
        stats: { ...prev.stats, [field]: Number(value) }
    }));
  };

  // --- LOCATION LOGIC ---
  const handleEditLocation = (loc: LocationState) => {
    setEditingLocation(loc);
    setLocFormData({ ...loc });
  };

  const handleSaveLocation = async () => {
      if (!locFormData) return;
      setIsSaving(true);
      try {
          const newLocations = locations.map(l => l.id === locFormData.id ? locFormData : l);
          await onUpdateLocations(newLocations);
          setEditingLocation(null);
          triggerSaveFeedback();
      } catch (error) {
          alert("Error saving location to database.");
          console.error(error);
      } finally {
          setIsSaving(false);
      }
  };

  const updateLocField = (field: keyof LocationState, value: any) => {
      if (!locFormData) return;
      setLocFormData({ ...locFormData, [field]: value });
  };

  // --- AUDIO DIAGNOSTIC LOGIC (DEEP CHECK) ---
  const runAudioDiagnostics = async () => {
      setIsRunningDiag(true);
      const statuses: Record<string, { status: string, details: string, path: string }> = {};
      
      // 1. Check Standard SFX & Music
      for (const [key, path] of Object.entries(SOUND_MAP)) {
          await checkFile(key, path, statuses);
      }

      // 2. Check Voices
      for (const [category, paths] of Object.entries(VOICE_COLLECTION)) {
          for (const path of paths) {
               // Use filename as key for display
               const key = `VOICE: ${category} / ${path.split('/').pop()}`;
               await checkFile(key, path, statuses);
          }
      }
      
      setAudioStatuses(statuses);
      setIsRunningDiag(false);
  };

  const checkFile = async (key: string, path: string, statuses: Record<string, any>) => {
      try {
              const response = await fetch(path);
              
              if (response.ok) {
                   const blob = await response.blob();
                   const contentType = response.headers.get('content-type');

                   // CHECK FILE SIGNATURE
                   const buffer = await blob.arrayBuffer();
                   const header = new Uint8Array(buffer.slice(0, 4));
                   let headerHex = "";
                   header.forEach(b => headerHex += b.toString(16).toUpperCase().padStart(2, '0') + " ");
                   
                   let detectedFormat = "Unknown";
                   let status = "OK";
                   
                   if (headerHex.startsWith("4F 67 67 53")) {
                       detectedFormat = "OGG (Valid)";
                   } 
                   else if (headerHex.startsWith("49 44 33") || headerHex.startsWith("FF FB")) {
                       detectedFormat = "MP3";
                       if (path.endsWith('.ogg')) status = "MISMATCH";
                   }
                   else if (headerHex.startsWith("52 49 46 46")) {
                       detectedFormat = "WAV";
                       if (path.endsWith('.ogg')) status = "MISMATCH";
                   }
                   else if (headerHex.startsWith("3C 21 44 4F") || contentType?.includes('text/html')) {
                       detectedFormat = "HTML (404 Error)";
                       status = "MISSING";
                   }

                   let details = `Type: ${detectedFormat}`;
                   if (status === 'MISMATCH') {
                       details += ` (Renamed incorrectly?)`;
                   } else if (status === 'OK') {
                       details += ` (${(blob.size / 1024).toFixed(1)} KB)`;
                   }

                   statuses[key] = { status, details, path };
              } else {
                  statuses[key] = { status: "MISSING", details: `HTTP ${response.status}`, path };
              }
          } catch (e: any) {
              statuses[key] = { status: "ERROR", details: e.message, path };
          }
  };

  const filteredLibrary = library.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Helper to render an audio check row
  const renderAudioRow = (key: string, data: { status: string, details: string, path: string }) => {
     if (!data) return null;
     const status = data.status;
     const isMissing = status === 'MISSING';
     const isMismatch = status === 'MISMATCH';
     const isOk = status === 'OK';
     const path = data.path;

     return (
         <div key={key} className={`flex items-center justify-between p-3 rounded border transition-colors group mb-2 ${isMissing ? 'bg-red-950/30 border-red-900' : isMismatch ? 'bg-yellow-900/20 border-yellow-600' : 'bg-black/40 border-stone-800'}`}>
             <div>
                 <div className="flex items-center gap-2">
                    <div className="text-amber-100 font-bold font-mono text-sm tracking-wide group-hover:text-amber-400 transition-colors">{key.replace('VOICE: ', '')}</div>
                    {status && (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${isOk ? 'bg-green-900 text-green-300' : isMismatch ? 'bg-yellow-800 text-yellow-200' : 'bg-red-900 text-red-300'}`}>
                            {status}
                        </span>
                    )}
                 </div>
                 <div className="text-[10px] text-stone-600 font-mono mt-1 break-all">{path}</div>
                 {data.details && <div className="text-[10px] text-stone-400 font-mono mt-1">{data.details}</div>}
             </div>
             <button 
                 onClick={() => path && playAudioFile(path)}
                 className="bg-stone-800 hover:bg-amber-700 text-stone-300 hover:text-white px-6 py-2 rounded font-bold uppercase text-[10px] tracking-widest transition-all border border-stone-600 hover:border-amber-500 flex items-center gap-2 shadow-lg active:scale-95 whitespace-nowrap"
             >
                 <span>▶</span> Play
             </button>
         </div>
     );
  };

  return (
    <div className="h-screen w-screen bg-stone-950 flex flex-col text-stone-200 font-sans">
      
      {showSaveSuccess && (
          <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-green-900 border border-green-500 text-white px-6 py-2 rounded-full z-[300] shadow-2xl animate-bounce flex items-center gap-2">
              <span>✅</span> Saved to Database
          </div>
      )}

      {/* Header */}
      <div className="bg-stone-900 p-4 border-b border-amber-900/40 flex justify-between items-center shadow-md z-10">
        <div className="flex items-center gap-4">
            <button onClick={onBack} className="text-stone-500 hover:text-amber-500 font-serif font-bold text-xs uppercase tracking-widest">
                ← Back
            </button>
            <h1 className="text-xl font-bold font-serif text-amber-500 tracking-wider">
                REALM ADMIN
            </h1>
        </div>
        
        <div className="flex bg-stone-950 p-1 rounded-sm border border-stone-800">
            <button 
                onClick={() => { setActiveTab('CARDS'); setEditingLocation(null); }}
                className={`px-4 py-1 text-xs font-bold uppercase tracking-widest transition-colors ${activeTab === 'CARDS' ? 'bg-amber-700 text-white' : 'text-stone-500 hover:text-stone-300'}`}
            >
                Cards
            </button>
            <button 
                onClick={() => { setActiveTab('LOCATIONS'); setEditingCard(null); }}
                className={`px-4 py-1 text-xs font-bold uppercase tracking-widest transition-colors ${activeTab === 'LOCATIONS' ? 'bg-amber-700 text-white' : 'text-stone-500 hover:text-stone-300'}`}
            >
                Battlefields
            </button>
            <button 
                onClick={() => { setActiveTab('AUDIO'); setEditingCard(null); setEditingLocation(null); }}
                className={`px-4 py-1 text-xs font-bold uppercase tracking-widest transition-colors ${activeTab === 'AUDIO' ? 'bg-amber-700 text-white' : 'text-stone-500 hover:text-stone-300'}`}
            >
                Audio Check
            </button>
        </div>

        <div className="flex gap-4">
             <button 
                onClick={handleImportFromCode}
                className="bg-blue-900 hover:bg-blue-700 text-blue-100 border border-blue-600 px-3 py-1 rounded-sm font-bold text-[10px] uppercase flex items-center gap-2"
                title="Overwrite database with constants.ts"
            >
                🔄 Import from Code
            </button>

            <button 
                onClick={onResetAll}
                className="text-[10px] text-red-900 hover:text-red-500 transition-colors uppercase font-bold border border-red-950 px-2 py-1 rounded"
            >
                Factory Reset
            </button>
            {activeTab === 'CARDS' && (
                <button 
                    onClick={handleCreateNewCard}
                    className="bg-green-800 hover:bg-green-700 text-green-100 border border-green-600 px-4 py-1 rounded-sm font-bold text-xs uppercase"
                >
                    + New Card
                </button>
            )}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* ... (Previous Cards and Locations Code omitted for brevity, logic remains identical) ... */}
        {activeTab === 'CARDS' && (
            <>
                <div 
                    className="flex-1 overflow-y-auto p-6 bg-cover bg-center relative"
                    style={{ backgroundImage: "url('https://res.cloudinary.com/dokkkdftz/image/upload/v1768619228/Hailuo_Image_com_base_nessa_imagem_sem_per_468767438506885120_resvc1.jpg?q=80&w=2074&auto=format&fit=crop')" }}
                >
                    <div className="absolute inset-0 bg-black/70 pointer-events-none z-0"></div>
                    <div className="relative z-10">
                        <div className="mb-4">
                            <input 
                                type="text" 
                                placeholder="Search cards..." 
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="bg-stone-900/90 border border-stone-700 rounded-sm px-4 py-2 text-sm focus:outline-none focus:border-amber-600 text-stone-300 w-full max-w-md backdrop-blur-sm"
                            />
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-8 place-items-center">
                            {filteredLibrary.map(card => (
                                <div key={card.id} className="relative group">
                                    <div onClick={() => handleEditCard(card)} className="cursor-pointer hover:scale-105 transition-transform duration-200">
                                        <Card data={card} size="md" isPlayable={false} disableGrayscale={true} />
                                    </div>
                                    <div className="absolute -top-3 -right-3 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); handleDeleteCard(card.id); }}
                                            className="bg-red-900 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shadow-md border border-red-500 hover:bg-red-700"
                                        >
                                            X
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                {editingCard && (
                    <div className="w-96 bg-stone-900/95 backdrop-blur-sm border-l border-amber-900/40 p-6 overflow-y-auto shadow-2xl animate-in slide-in-from-right relative z-20">
                        <h2 className="text-2xl font-serif font-bold mb-6 text-amber-500 border-b border-stone-800 pb-2">Edit Champion</h2>
                        <div className="space-y-4">
                            <div className="flex justify-center mb-6 scale-100">
                                <Card data={cardFormData} isPlayable={false} size="md" disableGrayscale={true} />
                            </div>
                            <div className="mb-2 bg-red-950/20 p-2 border border-red-900/30 rounded">
                                <label className="block text-[10px] uppercase text-stone-400 font-bold mb-1 tracking-widest">Unique ID</label>
                                <input type="text" value={cardFormData.id} onChange={e => updateCardField('id', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-2 text-amber-500 focus:border-amber-600 outline-none font-mono text-xs font-bold"/>
                            </div>
                            <div>
                                <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Name</label>
                                <input type="text" value={cardFormData.name} onChange={e => updateCardField('name', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-2 text-stone-200 focus:border-amber-600 outline-none"/>
                            </div>
                            <div>
                                <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Image URL</label>
                                <input type="text" value={cardFormData.image_url} onChange={e => updateCardField('image_url', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-2 text-xs text-stone-400 focus:border-amber-600 outline-none"/>
                            </div>
                             <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Cost</label>
                                    <input type="number" value={cardFormData.power_cost} onChange={e => updateCardField('power_cost', Number(e.target.value))} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-2 text-stone-200 outline-none"/>
                                </div>
                                <div>
                                    <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Affinity / Type</label>
                                    <select value={cardFormData.affinity || 'Standard'} onChange={e => updateCardField('affinity', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-2 text-stone-200 text-xs outline-none">
                                        {AVAILABLE_AFFINITIES.map(c => <option key={c} value={c}>{c}</option>)}
                                    </select>
                                </div>
                            </div>
                             <div>
                                <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Class</label>
                                <select value={cardFormData.class} onChange={e => updateCardField('class', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-2 text-stone-200 text-xs outline-none">
                                    {AVAILABLE_CLASSES.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-4 bg-stone-950 p-2 border border-stone-800">
                                <div>
                                    <label className="block text-[10px] uppercase text-red-800 font-bold mb-1">Attack</label>
                                    <input type="number" value={cardFormData.stats.atack} onChange={e => updateCardStats('atack', Number(e.target.value))} className="w-full bg-stone-900 border border-stone-700 rounded-sm p-2 text-stone-200 outline-none"/>
                                </div>
                                <div>
                                    <label className="block text-[10px] uppercase text-sky-800 font-bold mb-1">Defense</label>
                                    <input type="number" value={cardFormData.stats.defense} onChange={e => updateCardStats('defense', Number(e.target.value))} className="w-full bg-stone-900 border border-stone-700 rounded-sm p-2 text-stone-200 outline-none"/>
                                </div>
                            </div>
                            <div className="flex gap-2 pt-6">
                                <button onClick={handleSaveCard} disabled={isSaving} className="flex-1 bg-amber-700 hover:bg-amber-600 disabled:bg-stone-700 disabled:text-stone-500 text-amber-100 font-serif font-bold py-2 rounded-sm border border-amber-500 transition-colors">
                                    {isSaving ? "Saving..." : "Save to Cloud"}
                                </button>
                                <button onClick={() => setEditingCard(null)} disabled={isSaving} className="px-4 bg-stone-800 text-stone-400 rounded-sm border border-stone-600 font-serif hover:text-stone-200">Cancel</button>
                            </div>
                        </div>
                    </div>
                )}
            </>
        )}

        {activeTab === 'LOCATIONS' && (
             <>
             <div className="flex-1 overflow-y-auto p-12 flex flex-col items-center bg-cover bg-center relative" style={{ backgroundImage: "url('https://res.cloudinary.com/dokkkdftz/image/upload/v1768619228/Hailuo_Image_com_base_nessa_imagem_sem_per_468767438506885120_resvc1.jpg?q=80&w=2074&auto=format&fit=crop')" }}>
                 <div className="absolute inset-0 bg-black/70 pointer-events-none z-0"></div>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl relative z-10">
                     {locations.map(loc => (
                         <div key={loc.id} onClick={() => handleEditLocation(loc)} className="group relative cursor-pointer border-4 border-stone-800 bg-stone-900 rounded-lg overflow-hidden h-[500px] hover:border-amber-600 transition-all shadow-2xl hover:scale-[1.02]">
                             <div className="h-full w-full relative">
                                 <img src={loc.imageUrl} className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity" />
                                 <div className="absolute inset-0 bg-stone-950/50 mix-blend-multiply"></div>
                                 <div className="absolute inset-0 flex items-center justify-center">
                                     <h2 className="text-3xl font-black text-stone-300 rustic-title text-center px-4 drop-shadow-lg">{loc.name}</h2>
                                 </div>
                             </div>
                             <div className="absolute bottom-0 inset-x-0 bg-stone-950/90 p-4 border-t border-stone-700">
                                 <p className="text-stone-400 text-sm italic text-center">"{loc.description}"</p>
                             </div>
                         </div>
                     ))}
                 </div>
             </div>
             {editingLocation && locFormData && (
                <div className="w-96 bg-stone-900/95 backdrop-blur-sm border-l border-amber-900/40 p-6 overflow-y-auto shadow-2xl animate-in slide-in-from-right relative z-20">
                    <h2 className="text-2xl font-serif font-bold mb-6 text-amber-500 border-b border-stone-800 pb-2">Modify Battlefield</h2>
                    <div className="mb-6 rounded-lg border-2 border-stone-700 overflow-hidden h-40">
                        <img src={locFormData.imageUrl} className="w-full h-full object-cover" />
                    </div>
                    <div className="space-y-6">
                        <div>
                            <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Name</label>
                            <input type="text" value={locFormData.name} onChange={e => updateLocField('name', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-3 text-stone-200 outline-none font-serif text-lg"/>
                        </div>
                        <div>
                            <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Background URL</label>
                            <input type="text" value={locFormData.imageUrl} onChange={e => updateLocField('imageUrl', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-3 text-xs text-stone-400 outline-none"/>
                        </div>
                        <div>
                            <label className="block text-[10px] uppercase text-stone-500 font-bold mb-1 tracking-widest">Flavor Text</label>
                            <textarea value={locFormData.description} onChange={e => updateLocField('description', e.target.value)} className="w-full bg-stone-950 border border-stone-700 rounded-sm p-3 text-stone-300 italic outline-none h-24 resize-none"/>
                        </div>
                        <div className="flex gap-2 pt-6">
                                <button onClick={handleSaveLocation} disabled={isSaving} className="flex-1 bg-amber-700 hover:bg-amber-600 disabled:bg-stone-700 disabled:text-stone-500 text-amber-100 font-serif font-bold py-2 rounded-sm border border-amber-500 transition-colors">
                                    {isSaving ? "Updating DB..." : "Update Battlefield"}
                                </button>
                                <button onClick={() => setEditingLocation(null)} disabled={isSaving} className="px-4 bg-stone-800 text-stone-400 rounded-sm border border-stone-600 font-serif hover:text-stone-200">Cancel</button>
                        </div>
                    </div>
                </div>
             )}
             </>
        )}

        {/* AUDIO TEST TAB */}
        {activeTab === 'AUDIO' && (
            <div className="flex-1 overflow-y-auto p-12 bg-stone-950 relative">
                 <div className="absolute inset-0 bg-black/50 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-50"></div>
                 
                 <div className="relative z-10 max-w-4xl mx-auto bg-stone-900 border border-stone-800 rounded-lg p-8 shadow-2xl">
                     <div className="flex justify-between items-center border-b border-stone-800 pb-4 mb-6">
                         <h2 className="text-2xl font-serif font-bold text-amber-500">
                             Audio Systems Diagnostic
                         </h2>
                         <button 
                            onClick={runAudioDiagnostics}
                            disabled={isRunningDiag}
                            className="bg-amber-900/50 border border-amber-600 text-amber-200 hover:bg-amber-700 px-4 py-2 rounded font-bold uppercase text-xs tracking-widest flex items-center gap-2"
                         >
                             {isRunningDiag ? 'Scanning...' : 'Run Diagnostics'}
                         </button>
                     </div>
                     
                     <div className="grid gap-3">
                         {/* MUSIC TRACKS */}
                         <div className="text-xs font-bold text-stone-500 mt-2 mb-2 uppercase tracking-widest border-b border-stone-800 pb-2 flex items-center gap-2">
                             <span>🎵</span> Soundtrack
                         </div>
                         {Object.entries(audioStatuses)
                            .filter(([key]) => key === 'INTRO' || key.startsWith('THEME_'))
                            .map(([key, data]) => renderAudioRow(key, data as { status: string, details: string, path: string }))}

                         {/* SFX */}
                         <div className="text-xs font-bold text-stone-500 mt-6 mb-2 uppercase tracking-widest border-b border-stone-800 pb-2 flex items-center gap-2">
                             <span>🔊</span> Sound Effects (SFX)
                         </div>
                         {Object.entries(audioStatuses)
                            .filter(([key]) => !key.startsWith('VOICE') && key !== 'INTRO' && !key.startsWith('THEME_'))
                            .map(([key, data]) => renderAudioRow(key, data as { status: string, details: string, path: string }))}

                         {/* VOICE FILES */}
                         <div className="text-xs font-bold text-stone-500 mt-6 mb-2 uppercase tracking-widest border-b border-stone-800 pb-2 flex items-center gap-2">
                             <span>🗣️</span> Voice Lines
                         </div>
                         {Object.keys(audioStatuses).length === 0 && <div className="text-stone-600 italic text-sm p-4">Diagnostics pending...</div>}
                         {Object.entries(audioStatuses)
                            .filter(([key]) => key.startsWith('VOICE'))
                            .map(([key, data]) => renderAudioRow(key, data as { status: string, details: string, path: string }))}
                     </div>
                     
                     <div className="mt-8 p-4 bg-stone-900 border border-stone-700 rounded text-stone-400 text-xs text-center space-y-2">
                         <p>Files must be in <code className="text-white bg-black px-1 rounded">public/assets/sounds/</code></p>
                         <p>If you see <span className="text-yellow-400 font-bold">MISMATCH</span>, you likely renamed a .MP3 file to .OGG manually. Browsers will reject this.</p>
                         <p>Click "Run Diagnostics" to scan for all voice files.</p>
                     </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
}
