
import React, { useState, useEffect, useRef } from 'react';
import { CardData, LocationState, PlayedCard, Posture, GamePhase, UserProfile, CardAffinity } from '../types';
import { MAX_TURNS, LOCATIONS_COUNT, RANKS, RANK_AVATARS, POINTS_RETREAT, AVATAR_OPTIONS, RANK_STYLES } from '../constants';
import Card from './Card';
import Location from './Location';
import CardInspector from './CardInspector';
import { generateBattleCommentary } from '../services/geminiService';
import { auth, db } from '../services/firebase';
import { playSound, playRandomVoice } from '../services/audioService'; // Updated Import

// Adjusted HandList:
// Increased lateral padding (px-12) to prevent cards from clipping at screen edges when zoomed.
// Relaxed hover spacing (-space-x-4) to reduce overlap clutter.
const HandList = ({ cards, onCardSelect, selectedCardId, energy }: { 
    cards: CardData[], 
    onCardSelect: (card: CardData) => void, 
    selectedCardId: string | null,
    energy: number 
}) => {
    return (
        <div className="w-full flex justify-center items-end pb-6 pt-8 overflow-x-visible relative z-10">
            {/* Increased negative space (-space-x-14) to handle wider cards elegantly */}
            <div className="flex -space-x-14 px-12 hover:-space-x-4 transition-all duration-500 ease-out"> 
                {cards.map((card, index) => (
                    <div 
                        key={card.id} 
                        className="transform transition-all duration-300 hover:-translate-y-12 hover:scale-110 hover:z-[200]"
                        style={{ 
                            zIndex: selectedCardId === card.id ? 100 : index,
                            transform: selectedCardId === card.id ? 'translateY(-40px) scale(1.1)' : `rotate(${(index - cards.length/2) * 3}deg) translateY(${Math.abs(index - cards.length/2) * 5}px)`
                        }}
                    >
                         <Card 
                            data={card} 
                            isSelected={selectedCardId === card.id}
                            isPlayable={card.power_cost <= energy}
                            onClick={() => onCardSelect(card)}
                         />
                    </div>
                ))}
            </div>
        </div>
    );
};

// --- AVATAR COMPONENT ---
interface AvatarProps {
    name: string;
    rankLevel: number; // 1-6
    affinity: CardAffinity; // Kept in props interface but not used for border anymore
    position: 'player' | 'opponent';
    customAvatarUrl?: string; // Optional override for image
    size?: 'normal' | 'large'; // NEW: Allow larger size for celebration
}

const Avatar = ({ name, rankLevel, affinity, position, customAvatarUrl, size = 'normal' }: AvatarProps) => {
    const isPlayer = position === 'player';
    const [isExpanded, setIsExpanded] = useState(false); // State to toggle visibility on mobile
    const rankName = RANKS[rankLevel] || 'Aliado';
    
    // Use custom avatar if provided, otherwise fallback to Rank Avatar
    const avatarUrl = customAvatarUrl || RANK_AVATARS[rankLevel] || RANK_AVATARS[1];

    // Determine Border/Glow based on RANK
    const rankStyle = RANK_STYLES[rankLevel] || RANK_STYLES[1];

    // Size Classes Logic
    const isLarge = size === 'large';
    const containerClass = isLarge 
        ? "relative w-40 h-40 md:w-56 md:h-56 flex items-center justify-center transition-all"
        : `absolute z-50 flex flex-col items-center ${isPlayer ? 'bottom-2 left-2 md:bottom-4 md:left-4 items-start md:items-center' : 'top-1 right-2'}`;

    const hexClass = isLarge
        ? "w-full h-full"
        : `${isPlayer ? `${isExpanded ? 'flex w-24 h-24 mb-2 animate-in zoom-in slide-in-from-bottom-5 duration-200' : 'hidden'} md:flex md:w-32 md:h-32` : 'flex w-14 h-14 md:w-16 md:h-16'}`;

    // UPDATED POSITIONS: Opponent moved to top-0 right-1
    return (
        <div 
            className={containerClass}
            onClick={() => isPlayer && !isLarge && setIsExpanded(!isExpanded)} // Toggle on tap only in normal mode
        >
            {/* WRAPPER: Holds Clipped Hexagon AND Floating Orb */}
            <div className={`
                relative
                ${hexClass} 
                items-center justify-center
                transition-all
            `}>
                {/* CLIPPED HEXAGON CONTAINER */}
                <div className="w-full h-full bg-black flex items-center justify-center relative"
                     style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                    
                    {/* Border Shim - Explicit Z-0 to stay behind */}
                    <div className={`absolute inset-0 bg-stone-800 z-0 ${isPlayer ? 'animate-pulse' : ''}`}></div>
                    
                    {/* Image Container - Explicit Z-10 to stay on top */}
                    <div className={`
                        absolute inset-[2px] md:inset-[3px] 
                        bg-stone-900 
                        flex items-center justify-center 
                        overflow-hidden
                        z-10
                    `}
                    style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}
                    >
                        <img src={avatarUrl} alt={name} className="w-full h-full object-cover" />
                        
                        {/* Inner Shadow/Gradient */}
                        <div className={`absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/80 pointer-events-none`}></div>
                    </div>
                </div>

                {/* RANK INDICATOR (Orb) - MOVED OUTSIDE THE CLIPPED CONTAINER */}
                {/* Z-50 ensures it stays on top of the clipped image */}
                <div className={`
                    absolute ${isLarge ? 'bottom-0 right-0 w-12 h-12 text-lg' : '-bottom-1 -right-1 w-6 h-6 md:w-8 md:h-8 text-[10px] md:text-xs'} 
                    rounded-full border-2 
                    flex items-center justify-center 
                    font-bold
                    z-50 
                    shadow-lg
                    ${rankStyle}
                `}>
                    {rankLevel}
                </div>
            </div>

            {/* Info Box - Always visible, but styled differently for mobile player */}
            {!isLarge && (
                <div className={`
                    mt-1 bg-black/80 backdrop-blur-md border border-stone-600 px-3 py-1 rounded-full text-center flex items-center gap-2
                    shadow-lg ${isPlayer ? 'scale-100 origin-bottom-left cursor-pointer active:scale-95 transition-transform' : 'scale-90 opacity-90'}
                `}>
                    {/* Mobile-only Rank Dot for Player (since Orb is hidden when collapsed) */}
                    {isPlayer && !isExpanded && (
                        <div className={`md:hidden w-2 h-2 rounded-full ${rankStyle.split(' ').pop()} shadow-[0_0_5px_currentColor]`}></div>
                    )}
                    
                    <div className="flex flex-col items-start md:items-center">
                        <div className="text-stone-400 font-serif font-bold text-[8px] md:text-[10px] uppercase tracking-widest leading-none">{rankName}</div>
                        <div className="text-stone-200 font-bold text-xs leading-none">{name}</div>
                    </div>
                </div>
            )}
        </div>
    );
};

// --- MINI INSPECTOR MODAL ---
const MiniCardInspector = ({ card, onClose }: { card: PlayedCard, onClose: () => void }) => {
    return (
        <div 
            className="fixed inset-0 z-[150] flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200" 
            onClick={onClose}
        >
            <div 
                className="bg-black/90 border border-amber-900/50 p-4 rounded-xl shadow-2xl flex flex-col gap-4 max-w-xs md:max-w-sm w-full relative transform animate-in zoom-in-95"
                onClick={e => e.stopPropagation()}
            >
                {/* Close Button */}
                <button onClick={onClose} className="absolute -top-2 -right-2 bg-stone-800 text-stone-400 w-8 h-8 rounded-full border border-stone-600 font-bold hover:bg-stone-700 z-50">✕</button>

                <div className="flex justify-center">
                    <div className="transform scale-110">
                        <Card data={card} size="md" isPlayable={false} disableGrayscale={true} />
                    </div>
                </div>
                
                <div className="bg-stone-900/80 rounded p-3 border border-stone-800">
                    <div className="text-center font-serif text-amber-500 font-bold tracking-widest uppercase mb-2 text-sm">{card.name}</div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-black/50 p-2 rounded border border-orange-900/30">
                            <div className="text-orange-400 font-bold uppercase text-[9px]">Atk Ability</div>
                            <div className="text-stone-300 italic">"{card.abilities.on_attack}"</div>
                        </div>
                        <div className="bg-black/50 p-2 rounded border border-violet-900/30">
                             <div className="text-violet-400 font-bold uppercase text-[9px]">Def Ability</div>
                             <div className="text-stone-300 italic">"{card.abilities.on_defense}"</div>
                        </div>
                    </div>
                    <div className="mt-2 text-[10px] text-stone-500 text-center uppercase tracking-widest">
                        Posture: <span className={card.mode === 'ATACK' ? 'text-orange-500' : 'text-violet-500'}>{card.mode}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

interface BattleScreenProps {
    playerDeckData: CardData[];
    fullLibrary: CardData[];
    initialLocations: LocationState[]; // Now acts as the Full Location Pool
    onGameEnd: (winner: boolean, retreated: boolean, opponentCards?: CardData[]) => void;
    onBack: () => void;
}

const BASE_TURN_TIME = 40;
const BOT_NAMES = ["Grimwolf", "Ironheart", "Shadow Weaver", "Stormcaller", "The Unseen", "Void Walker", "Sun Keeper", "Bloodletter", "Rune Master"];
const BOT_AFFINITIES: CardAffinity[] = ['Fire', 'Ice', 'Nature', 'Dark', 'Light', 'Earth', 'Wind', 'Electric'];

export default function BattleScreen({ playerDeckData, fullLibrary, initialLocations, onGameEnd, onBack }: BattleScreenProps) {
  // Game State
  const [turn, setTurn] = useState(1);
  const [energy, setEnergy] = useState(2); 
  const [phase, setPhase] = useState<GamePhase>('PLANNING');
  
  const [playerHand, setPlayerHand] = useState<CardData[]>([]);
  const [playerDeck, setPlayerDeck] = useState<CardData[]>([...playerDeckData].sort(() => Math.random() - 0.5)); 
  
  // RANDOM LOCATION SELECTION
  // We take the full pool (initialLocations) and randomly select 3 unique locations for this match.
  const [locations, setLocations] = useState<LocationState[]>(() => {
      // 1. Clone the pool to avoid mutation issues
      const pool = JSON.parse(JSON.stringify(initialLocations)) as LocationState[];
      const selectedLocations: LocationState[] = [];
      
      // 2. Randomly pick unique locations until we have LOCATIONS_COUNT (3)
      for (let i = 0; i < LOCATIONS_COUNT; i++) {
          if (pool.length === 0) break;
          const randomIndex = Math.floor(Math.random() * pool.length);
          const picked = pool.splice(randomIndex, 1)[0];
          selectedLocations.push(picked);
      }
      return selectedLocations;
  });
  
  const [selectedCard, setSelectedCard] = useState<CardData | null>(null);
  const [inspectingCard, setInspectingCard] = useState<CardData | null>(null); // For Full Screen Inspector (Hand)
  const [miniInspectCard, setMiniInspectCard] = useState<PlayedCard | null>(null); // For Mini Inspector (Board)
  
  const [modalOpen, setModalOpen] = useState(false);
  const [targetLocationIndex, setTargetLocationIndex] = useState<number | null>(null);
  
  // Retreat Modal State
  const [showRetreatModal, setShowRetreatModal] = useState(false);
  
  const [commentary, setCommentary] = useState<string>("The battle horn sounds. Make your move.");

  // Timer State
  const [timeLeft, setTimeLeft] = useState(BASE_TURN_TIME); 
  const [timeBank, setTimeBank] = useState(0);  // Saved seconds from previous turns
  // Ref to track if turn ended automatically to avoid loops
  const turnEndProcessing = useRef(false);

  // Player Data from DB for Avatar
  const [playerProfile, setPlayerProfile] = useState<UserProfile | null>(null);
  
  // Opponent Data (Dynamic Matchmaking)
  const [opponentProfile, setOpponentProfile] = useState<{name: string, rank: number, affinity: CardAffinity}>({
      name: "Searching...",
      rank: 1,
      affinity: 'Dark'
  });

  // Initialization
  useEffect(() => {
    drawCards(3);
    playSound('BATTLE_START'); // Sound: Battle Start SFX
    
    // Play a random "Start Battle" voice line after a small delay
    setTimeout(() => {
        playRandomVoice('START');
    }, 1500);
    
    // Fetch user profile for avatar
    if (auth.currentUser) {
        db.collection('users').doc(auth.currentUser.uid).get().then(doc => {
            if (doc.exists) {
                const userData = doc.data() as UserProfile;
                setPlayerProfile(userData);

                // --- MATCHMAKING LOGIC ---
                let enemyRank = 1;
                let matchMessage = "";

                if (userData.points <= 20) {
                    // Safety Bracket: Same Level Matchmaking
                    enemyRank = userData.level;
                    matchMessage = "⚔️ Honor Guard Active: Opponent matched to your rank.";
                } else {
                    // Standard Matchmaking: Random Rank 1-6
                    enemyRank = Math.floor(Math.random() * 6) + 1;
                }

                // Generate Bot Identity
                const randomName = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
                const randomAffinity = BOT_AFFINITIES[Math.floor(Math.random() * BOT_AFFINITIES.length)];

                setOpponentProfile({
                    name: randomName,
                    rank: enemyRank,
                    affinity: randomAffinity
                });

                setCommentary(matchMessage || "The battle horn sounds. Make your move.");
            }
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Timer Logic
  useEffect(() => {
      let interval: ReturnType<typeof setInterval>;
      
      if (phase === 'PLANNING' && !turnEndProcessing.current) {
          interval = setInterval(() => {
              setTimeLeft((prev) => {
                  if (prev <= 1) {
                      clearInterval(interval);
                      return 0;
                  }
                  return prev - 1;
              });
          }, 1000);
      }

      return () => clearInterval(interval);
  }, [phase]);

  // Auto-end turn when time expires
  useEffect(() => {
      if (phase === 'PLANNING' && timeLeft === 0 && !turnEndProcessing.current) {
          endTurn(true);
      }
  }, [timeLeft, phase]);

  const drawCards = (count: number) => {
    setPlayerDeck(currentDeck => {
        const newDeck = [...currentDeck];
        const drawn: CardData[] = [];
        for (let i = 0; i < count; i++) {
            if (newDeck.length > 0) {
                const randomIndex = Math.floor(Math.random() * newDeck.length);
                drawn.push(newDeck.splice(randomIndex, 1)[0]);
            }
        }
        setPlayerHand(prev => [...prev, ...drawn]);
        return newDeck;
    });
  };

  const handleCardSelect = (card: CardData) => {
    if (phase !== 'PLANNING') return;
    
    if (card.power_cost > energy) {
        playSound('ERROR');
        setCommentary(`Insufficient Mana! Need ${card.power_cost}.`);
    }

    if (selectedCard?.id === card.id) {
        setInspectingCard(card);
        playSound('UI_CLICK');
        setCommentary("Examining the scrolls...");
    } else {
        if (card.power_cost <= energy) {
            playSound('CARD_SELECT'); // Sound: Card Select
            setSelectedCard(card);
            setCommentary("Choose a battlefield.");
        }
    }
  };

  const handleLocationClick = (index: number) => {
    if (selectedCard && phase === 'PLANNING') {
        if (locations[index].playerCards.length >= 4) {
            playSound('ERROR');
            setCommentary("This front is at capacity!");
            return;
        }
        playSound('UI_CLICK');
        setTargetLocationIndex(index);
        setModalOpen(true);
    } else if (!selectedCard && phase === 'PLANNING') {
        setCommentary("Choose a champion first.");
    }
  };

  // Drag and Drop Handler
  const handleCardDrop = (cardId: string, locationIndex: number) => {
    if (phase !== 'PLANNING') return;
    
    // Find the card from hand
    const card = playerHand.find(c => c.id === cardId);
    if (!card) return;

    // Validate Play
    if (card.power_cost > energy) {
        playSound('ERROR');
        setCommentary(`Insufficient Mana for ${card.name}!`);
        return;
    }

    if (locations[locationIndex].playerCards.length >= 4) {
        playSound('ERROR');
        setCommentary("This front is full!");
        return;
    }

    // Set State for Modal
    playSound('UI_CLICK');
    setSelectedCard(card);
    setTargetLocationIndex(locationIndex);
    setModalOpen(true);
  };

  const handleInspectPlayedCard = (card: PlayedCard) => {
      if (card.revealed) {
          playSound('UI_CLICK');
          setMiniInspectCard(card);
      }
  };

  // Funcao para cancelar a seleção ao clicar no fundo
  const handleBackgroundClick = () => {
    if (selectedCard) {
        setSelectedCard(null);
        playSound('UI_HOVER');
        setCommentary("Selection cancelled.");
    }
  };

  const calculateLocationScores = (loc: LocationState): LocationState => {
    const pScore = loc.playerCards.reduce((acc, card) => {
        const val = card.mode === 'ATACK' ? card.stats.atack : card.stats.defense;
        return acc + val;
    }, 0);

    const oScore = loc.opponentCards.reduce((acc, card) => {
        const val = card.mode === 'ATACK' ? card.stats.atack : card.stats.defense;
        return acc + val;
    }, 0);

    return { ...loc, playerScore: pScore, opponentScore: oScore };
  };

  const executePlayCard = (posture: Posture) => {
    if (!selectedCard || targetLocationIndex === null) return;

    setPlayerHand(prev => prev.filter(c => c.id !== selectedCard.id));
    setEnergy(prev => prev - selectedCard.power_cost);

    const newPlayedCard: PlayedCard = {
        ...selectedCard,
        instanceId: `${selectedCard.id}_${Date.now()}`,
        owner: 'player',
        mode: posture,
        revealed: true 
    };

    // Sound: Play Card
    if (posture === 'ATACK') playSound('CARD_PLAY_ATACK');
    else playSound('CARD_PLAY_DEFENSE');

    setLocations(prev => {
        return prev.map((loc, idx) => {
            if (idx === targetLocationIndex) {
                const updatedLoc = {
                    ...loc,
                    playerCards: [...loc.playerCards, newPlayedCard]
                };
                return calculateLocationScores(updatedLoc);
            }
            return loc;
        });
    });

    setSelectedCard(null);
    setModalOpen(false);
    setTargetLocationIndex(null);
    setCommentary("Orders received.");
  };

  const simulateOpponentMove = () => {
    const opponentEnergy = turn + 2; 
    let currentEnergy = opponentEnergy;

    const newMoves: { locIndex: number, card: PlayedCard }[] = [];
    const potentialCards = fullLibrary; 
    
    for (let i = 0; i < 2; i++) {
        if (potentialCards.length === 0) break;
        const randomCard = potentialCards[Math.floor(Math.random() * potentialCards.length)];
        if (randomCard.power_cost <= currentEnergy) {
             const locIndex = Math.floor(Math.random() * LOCATIONS_COUNT);
             if (locations[locIndex].opponentCards.length + newMoves.filter(m => m.locIndex === locIndex).length < 4) {
                const mode: Posture = Math.random() > 0.5 ? 'ATACK' : 'DEFENSE';
                
                newMoves.push({
                    locIndex,
                    card: {
                        ...randomCard,
                        instanceId: `opp_${Date.now()}_${i}`,
                        owner: 'opponent',
                        mode: mode,
                        revealed: false 
                    }
                });
                currentEnergy -= randomCard.power_cost;
             }
        }
    }
    return newMoves;
  };

  const endTurn = async (autoEnded = false) => {
    if (phase !== 'PLANNING' || turnEndProcessing.current) return;
    
    playSound('UI_CLICK');
    turnEndProcessing.current = true;
    
    const savedTime = autoEnded ? 0 : timeLeft;
    const newTotalBank = timeBank + savedTime;
    
    setTimeBank(newTotalBank); 
    
    if (autoEnded) {
        setCommentary("Time limit reached! Engaging forces...");
    }

    setPhase('RESOLVING');

    const opponentMoves = simulateOpponentMove();
    
    setLocations(prev => {
        return prev.map((loc, idx) => {
            const movesForLoc = opponentMoves.filter(m => m.locIndex === idx);
            if (movesForLoc.length > 0) {
                const updatedLoc = {
                    ...loc,
                    opponentCards: [...loc.opponentCards, ...movesForLoc.map(m => m.card)]
                };
                return calculateLocationScores(updatedLoc);
            }
            return loc;
        });
    });

    await new Promise(r => setTimeout(r, 800));

    setLocations(prev => {
        return prev.map(loc => {
            const updatedLoc = {
                ...loc,
                opponentCards: loc.opponentCards.map(c => ({ ...c, revealed: true }))
            };
            return calculateLocationScores(updatedLoc);
        });
    });

    const activeLocIndex = Math.floor(Math.random() * 3);
    
    if (turn >= MAX_TURNS) {
        // --- CELEBRATION PHASE CHANGE ---
        setPhase('CELEBRATION');
        
        // Count Wins for Audio
        let playerWins = 0;
        let opponentWins = 0;
        locations.forEach(loc => {
            if (loc.playerScore > loc.opponentScore) playerWins++;
            else if (loc.opponentScore > loc.playerScore) opponentWins++;
        });

        if (playerWins > opponentWins) {
            playSound('VICTORY');
            playRandomVoice('VICTORY');
        } else {
            playSound('DEFEAT');
            playRandomVoice('DEFEAT');
        }
        
    } else {
        const nextTurn = turn + 1;
        setTurn(nextTurn);
        setEnergy(nextTurn + 1); 
        drawCards(1);
        playSound('CARD_SELECT'); // Sound: Card Draw
        
        if (nextTurn === MAX_TURNS) {
            setTimeLeft(BASE_TURN_TIME + newTotalBank);
            setCommentary(`FINAL ROUND! Time Bank Unlocked: +${newTotalBank}s`);
        } else {
            setTimeLeft(BASE_TURN_TIME);
        }
        
        setPhase('PLANNING');
        turnEndProcessing.current = false;
        
        // --- LOCAL COMMENTARY LOGIC ---
        // Always generate commentary unless it's the final round announcement, 
        // effectively making it run every turn for dynamic feedback.
        if (nextTurn === 1 || nextTurn === 3 || nextTurn === MAX_TURNS || Math.random() > 0.6) {
            // Play a random commentary voice audio file
            playRandomVoice('COMMENTARY');

            // Generate local text based on game state
            generateBattleCommentary(nextTurn, locations[activeLocIndex]).then(result => {
                setCommentary(result.text);
            });
        }
    }
  };

  const handleGameEnd = () => {
      let playerWins = 0;
      let opponentWins = 0;
      
      // Collect all cards played by opponent to potentially reward one to player
      const opponentUsedCards: CardData[] = [];

      locations.forEach(loc => {
          if (loc.playerScore > loc.opponentScore) playerWins++;
          else if (loc.opponentScore > loc.playerScore) opponentWins++;
          
          // Collect opponent cards for loot logic
          loc.opponentCards.forEach(playedCard => {
              // Avoid duplicates in the pool? Or keep them to increase chance? 
              // Let's keep unique by ID for cleanliness in reward pool.
              if (!opponentUsedCards.find(c => c.id === playedCard.id)) {
                  opponentUsedCards.push(playedCard);
              }
          });
      });
      
      const isVictory = playerWins > opponentWins;
      
      // Pass the captured pool to the handler
      onGameEnd(isVictory, false, opponentUsedCards);
  };
  
  // Resolve Avatar URL for Player
  const playerAvatarUrl = playerProfile ? (AVATAR_OPTIONS.find(a => a.id === playerProfile.avatarId)?.url) : undefined;

  // Calculate Scores for Celebration
  let playerTotalWins = 0;
  let opponentTotalWins = 0;
  if (phase === 'CELEBRATION' || phase === 'GAME_OVER') {
      locations.forEach(loc => {
          if (loc.playerScore > loc.opponentScore) playerTotalWins++;
          else if (loc.opponentScore > loc.playerScore) opponentTotalWins++;
      });
  }

  // --- LOGIC TO BLINK END TURN BUTTON ---
  // Check if player has NO playable cards (based on Mana)
  const hasPlayableCards = playerHand.some(c => c.power_cost <= energy);
  const shouldHighlightEndTurn = !hasPlayableCards && phase === 'PLANNING';

  return (
    <div 
        onClick={handleBackgroundClick}
        className="h-screen w-screen bg-black text-stone-300 font-sans flex flex-col overflow-hidden select-none bg-cover bg-center bg-fixed cursor-default relative"
        style={{ backgroundImage: "url('https://res.cloudinary.com/dokkkdftz/image/upload/v1768619228/Hailuo_Image_com_base_nessa_imagem_sem_per_468767438506885120_resvc1.jpg?q=80&w=2074&auto=format&fit=crop')" }}
    >
      <div className="absolute inset-0 bg-black/20 pointer-events-none"></div>
      
      {/* HUD HEADER */}
      <div className="h-16 bg-black/60 border-b border-white/10 flex items-center justify-between px-2 md:px-6 z-30 shadow-2xl backdrop-blur-md relative">
        
        {/* LEFT: Retreat */}
        <button 
            onClick={(e) => { e.stopPropagation(); playSound('UI_CLICK'); setShowRetreatModal(true); }} 
            className="text-stone-400 hover:text-red-500 font-serif font-bold tracking-[0.1em] text-[10px] md:text-xs transition-colors border border-stone-600 hover:border-red-600 px-2 md:px-3 py-1 rounded hover:bg-stone-800"
        >
             ◄ RETREAT
        </button>
        
        {/* CENTER: Round - Timer - Mana */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center gap-4">
            {/* Round */}
            <div className="bg-black/50 px-2 md:px-4 py-1 border border-stone-700 rounded shadow-inner flex flex-col items-center">
                <span className="text-[8px] md:text-[10px] text-stone-500 uppercase tracking-[0.2em]">Round</span>
                <span className="text-sm md:text-xl font-serif font-bold text-amber-500 drop-shadow-md">{turn}/{MAX_TURNS}</span>
            </div>

            {/* Timer (Centerpiece) */}
             <div className="w-16 flex flex-col items-center justify-center">
                {phase === 'PLANNING' && (
                    <div className={`
                        text-xl font-black font-mono px-3 py-1 rounded border border-white/10 shadow-lg backdrop-blur
                        ${timeLeft <= 10 ? 'text-red-500 border-red-500/50 bg-red-950/40 animate-pulse' : 'text-amber-100 bg-black/40'}
                    `}>
                        0:{timeLeft.toString().padStart(2, '0')}
                    </div>
                )}
             </div>

            {/* Mana - UPDATED to Neon Violet */}
            <div className="flex flex-col items-center">
                 <div className="relative w-8 h-8 md:w-10 md:h-10 flex items-center justify-center animate-pulse">
                      <div className={`absolute inset-0 rotate-45 scale-75 border-2 transition-all duration-500 ${energy === 0 ? 'bg-stone-900 border-stone-700' : 'bg-violet-900/80 border-violet-400 shadow-[0_0_20px_rgba(139,92,246,0.6)]'}`}></div>
                      <span className="relative z-10 font-bold text-white text-sm md:text-lg drop-shadow-lg">{energy}</span>
                 </div>
                 <span className="text-[8px] md:text-[10px] uppercase font-bold text-violet-300 tracking-widest hidden md:inline -mt-1">Mana</span>
            </div>
        </div>

        {/* RIGHT: Cleared for Avatar or minimal status */}
        <div className="w-24 flex justify-end">
            {(phase === 'GAME_OVER' || phase === 'CELEBRATION') && (
                <div className="text-red-500 font-serif font-bold text-xs md:text-sm animate-pulse border border-red-500/50 px-2 py-1 bg-red-950/30">FINISHED</div>
            )}
        </div>
      </div>

      {/* --- AVATARS --- */}
      {/* Player Avatar */}
      {playerProfile && (
          <Avatar 
            name={playerProfile.name} 
            rankLevel={playerProfile.level} 
            affinity={playerProfile.mainAffinity} 
            position="player"
            customAvatarUrl={playerAvatarUrl}
          />
      )}

      {/* Opponent Avatar (Dynamic) */}
      <Avatar 
        name={opponentProfile.name} 
        rankLevel={opponentProfile.rank} 
        affinity={opponentProfile.affinity} 
        position="opponent"
      />

      {/* Main Board Area */}
      <div className="flex-1 p-3 gap-1 md:gap-3 flex items-center justify-center overflow-hidden relative z-10">
         {locations.map((loc, index) => (
             <Location 
                key={loc.id} 
                location={loc} 
                onSelect={() => handleLocationClick(index)}
                onDropCard={(cardId) => handleCardDrop(cardId, index)}
                onInspectCard={handleInspectPlayedCard}
                isActiveDrop={!!selectedCard && phase === 'PLANNING'}
                gamePhase={phase}
             />
         ))}
      </div>

      <div className="bg-black/80 border-y border-amber-900/30 py-1 text-center h-10 md:h-12 flex items-center justify-center relative shadow-[0_0_30px_rgba(0,0,0,1)] z-20 backdrop-blur-sm">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-900/10 to-transparent opacity-50"></div>
          <p className="text-xs md:text-sm text-amber-100/90 font-serif italic tracking-wide relative z-10 drop-shadow-md truncate px-4">
            <span className="text-amber-600 mr-2">✦</span>
            {commentary}
            <span className="text-amber-600 ml-2">✦</span>
          </p>
      </div>

      <div className="h-56 md:h-64 bg-gradient-to-t from-black/95 via-black/80 to-black/60 border-t border-stone-800/50 relative z-40 backdrop-blur-md shadow-[0_-10px_50px_rgba(0,0,0,0.8)]">
         <div className="absolute top-0 left-0 w-full h-[1px] bg-white/10"></div>
         
         {/* REMOVED PREVIOUS END TURN BUTTON LOCATION */}

         <HandList 
            cards={playerHand} 
            selectedCardId={selectedCard?.id || null} 
            onCardSelect={handleCardSelect}
            energy={energy}
         />
      </div>

      {/* END TURN BUTTON - MOVED TO BOTTOM RIGHT FOR BOTH MOBILE AND DESKTOP */}
      {phase === 'PLANNING' && (
        <button 
            onClick={(e) => { e.stopPropagation(); endTurn(false); }}
            className={`
                absolute z-50 text-white font-bold tracking-widest uppercase transition-all shadow-lg
                
                /* Base Styles: Bottom Right Floating Pill */
                bottom-8 right-4 px-6 py-3 rounded-full text-xs border-2
                
                /* Desktop Adjustments: Slightly larger and more offset for balance */
                md:bottom-10 md:right-10 md:px-8 md:py-4 md:text-sm

                ${shouldHighlightEndTurn 
                    ? 'bg-amber-500 animate-pulse ring-2 ring-amber-200 border-amber-300 shadow-[0_0_20px_rgba(245,158,11,0.8)] scale-105' 
                    : 'bg-amber-600 hover:bg-amber-500 border-amber-400 shadow-[0_4px_10px_rgba(0,0,0,0.5)] hover:scale-105 active:scale-95'
                }
            `}
        >
            End Turn
        </button>
      )}

      {inspectingCard && (
        <CardInspector 
            card={inspectingCard} 
            onClose={() => { playSound('UI_CLICK'); setInspectingCard(null); }} 
        />
      )}

      {miniInspectCard && (
          <MiniCardInspector 
            card={miniInspectCard}
            onClose={() => { playSound('UI_CLICK'); setMiniInspectCard(null); }}
          />
      )}

      {/* --- RETREAT CONFIRMATION MODAL --- */}
      {showRetreatModal && (
        <div className="fixed inset-0 z-[150] bg-black/90 flex items-center justify-center backdrop-blur-sm animate-in fade-in" onClick={() => setShowRetreatModal(false)}>
            <div className="bg-stone-900 border-2 border-red-900 p-8 rounded-lg max-w-md w-full text-center shadow-[0_0_50px_rgba(220,38,38,0.2)]" onClick={(e) => e.stopPropagation()}>
                <h2 className="text-3xl text-red-500 font-serif font-bold mb-4 tracking-widest">ABANDON BATTLE?</h2>
                <div className="w-16 h-1 bg-red-900/50 mx-auto mb-6"></div>
                <p className="text-stone-300 mb-2 font-serif text-lg">Are you sure you want to flee?</p>
                <div className="bg-black/40 p-4 border border-red-900/30 rounded mb-8">
                    <p className="text-red-400 font-bold text-sm uppercase tracking-widest">
                        ⚠️ PENALTY: -{POINTS_RETREAT} HONOR POINTS
                    </p>
                </div>
                <div className="flex gap-4 justify-center">
                    <button 
                        onClick={() => { playSound('UI_CLICK'); setShowRetreatModal(false); }}
                        className="px-6 py-3 border border-stone-600 rounded hover:bg-stone-800 text-stone-400 font-bold tracking-widest transition-colors w-1/2"
                    >
                        CANCEL
                    </button>
                    <button 
                        onClick={() => { playSound('DEFEAT'); onGameEnd(false, true); }}
                        className="px-6 py-3 bg-red-900 border border-red-700 rounded hover:bg-red-800 hover:scale-105 text-white font-bold shadow-lg tracking-widest transition-all w-1/2"
                    >
                        FLEE
                    </button>
                </div>
            </div>
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md animate-in fade-in duration-200" onClick={(e) => e.stopPropagation()}>
            <div className="bg-stone-900/90 p-1 border border-stone-600 max-w-lg w-full shadow-2xl relative rounded-xl overflow-hidden mx-4">
                <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 to-transparent pointer-events-none"></div>
                
                <div className="bg-black/50 p-6 md:p-8 rounded-lg backdrop-blur-sm border border-black/50">
                    <h3 className="text-2xl md:text-3xl text-center text-amber-500 font-serif font-black mb-6 md:mb-10 tracking-[0.2em] border-b border-stone-700 pb-4 uppercase drop-shadow-md">
                        Command Posture
                    </h3>
                    
                    <div className="flex gap-4 md:gap-6">
                        {/* ASSAULT BUTTON - UPDATED TO ORANGE THEME */}
                        <button 
                            onClick={() => executePlayCard('ATACK')}
                            className="flex-1 bg-gradient-to-br from-orange-950 to-black border border-orange-900 hover:border-orange-500 text-orange-100 p-4 md:p-6 flex flex-col items-center gap-2 md:gap-4 transition-all hover:-translate-y-1 group rounded-lg shadow-[0_0_20px_rgba(234,88,12,0.2)] hover:shadow-[0_0_30px_rgba(234,88,12,0.4)]"
                        >
                            <div className="text-4xl md:text-5xl group-hover:scale-110 transition-transform drop-shadow-[0_0_10px_rgba(249,115,22,0.8)]">⚔️</div>
                            <div className="text-center">
                                <span className="block font-serif font-bold tracking-widest text-sm md:text-lg text-orange-400">ASSAULT</span>
                                <span className="text-[9px] md:text-[10px] text-stone-400 uppercase tracking-wide mt-1 block">Attack Power: {selectedCard?.stats.atack}</span>
                            </div>
                        </button>
                        
                        {/* GUARD BUTTON - UPDATED TO NEON VIOLET THEME */}
                        <button 
                            onClick={() => executePlayCard('DEFENSE')}
                            className="flex-1 bg-gradient-to-br from-violet-950 to-black border border-violet-900 hover:border-violet-500 text-violet-100 p-4 md:p-6 flex flex-col items-center gap-2 md:gap-4 transition-all hover:-translate-y-1 group rounded-lg shadow-[0_0_20px_rgba(139,92,246,0.2)] hover:shadow-[0_0_30px_rgba(139,92,246,0.4)]"
                        >
                            <div className="text-4xl md:text-5xl group-hover:scale-110 transition-transform drop-shadow-[0_0_10px_rgba(139,92,246,0.8)]">🛡️</div>
                            <div className="text-center">
                                <span className="block font-serif font-bold tracking-widest text-sm md:text-lg text-violet-400">GUARD</span>
                                <span className="text-[9px] md:text-[10px] text-stone-400 uppercase tracking-wide mt-1 block">Defense Power: {selectedCard?.stats.defense}</span>
                            </div>
                        </button>
                    </div>
                    <button 
                        onClick={() => { playSound('UI_CLICK'); setModalOpen(false); }}
                        className="w-full mt-6 md:mt-8 text-stone-600 hover:text-stone-300 py-2 cursor-pointer font-serif text-xs uppercase tracking-[0.3em] transition-colors"
                    >
                        Cancel Order
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* --- CELEBRATION / RESULT OVERLAY --- */}
      {phase === 'CELEBRATION' && playerProfile && (
           <div 
                onClick={() => setPhase('GAME_OVER')} 
                className="fixed inset-0 z-[100] bg-black/60 flex flex-col items-center justify-center animate-in fade-in zoom-in duration-500 backdrop-blur-sm cursor-pointer"
           >
               {/* Radial Glow based on outcome */}
               <div className={`absolute inset-0 opacity-40 ${playerTotalWins > opponentTotalWins ? 'bg-[radial-gradient(circle,rgba(245,158,11,0.5)_0%,transparent_70%)]' : 'bg-[radial-gradient(circle,rgba(234,88,12,0.5)_0%,transparent_70%)]'}`}></div>

               <div className="relative z-10 flex flex-col items-center gap-6">
                   {/* Giant Player Avatar */}
                   <div className="transform scale-150 mb-4 animate-bounce-in">
                       <Avatar 
                            name={playerProfile.name} 
                            rankLevel={playerProfile.level} 
                            affinity={playerProfile.mainAffinity} 
                            position="player"
                            customAvatarUrl={playerAvatarUrl}
                            size="large"
                       />
                   </div>

                   {/* Outcome Text */}
                   <h1 className={`text-6xl md:text-8xl font-black font-serif tracking-widest drop-shadow-[0_10px_10px_rgba(0,0,0,1)] uppercase ${playerTotalWins > opponentTotalWins ? 'text-amber-500' : 'text-stone-500'}`}>
                       {playerTotalWins > opponentTotalWins ? 'VICTORY' : 'DEFEAT'}
                   </h1>

                   {/* Scoreboard */}
                   <div className="flex items-center gap-8 bg-black/80 px-8 py-4 rounded-full border border-stone-700 shadow-2xl">
                       <div className="flex flex-col items-center">
                           <span className="text-xs text-stone-400 uppercase tracking-widest mb-1">You</span>
                           <span className={`text-4xl font-bold ${playerTotalWins > opponentTotalWins ? 'text-amber-400' : 'text-stone-500'}`}>{playerTotalWins}</span>
                       </div>
                       <span className="text-2xl text-stone-600 font-bold">VS</span>
                       <div className="flex flex-col items-center">
                           <span className="text-xs text-stone-400 uppercase tracking-widest mb-1">Enemy</span>
                           <span className={`text-4xl font-bold ${opponentTotalWins > playerTotalWins ? 'text-orange-500' : 'text-stone-500'}`}>{opponentTotalWins}</span>
                       </div>
                   </div>

                   <p className="mt-8 text-stone-400 text-xs uppercase tracking-[0.3em] animate-pulse">Tap to Continue</p>
               </div>
           </div>
      )}

      {/* --- FINAL SUMMARY --- */}
      {phase === 'GAME_OVER' && (
          <div className="fixed inset-0 z-[100] bg-black/90 flex flex-col items-center justify-center animate-in fade-in duration-1000 backdrop-blur-md">
              <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-b from-amber-300 to-amber-700 mb-10 md:mb-16 tracking-widest font-serif drop-shadow-[0_10px_10px_rgba(0,0,0,1)] uppercase italic text-center px-4">
                  Battle Resolve
              </h1>
              
              <div className="flex flex-col md:flex-row gap-4 md:gap-6 max-w-6xl w-full justify-center px-4 overflow-y-auto max-h-[60vh]">
                {locations.map(loc => {
                     const pWin = loc.playerScore > loc.opponentScore;
                     const tie = loc.playerScore === loc.opponentScore;
                     return (
                        <div key={loc.id} className={`
                            flex-1 p-4 md:p-8 border flex flex-row md:flex-col items-center justify-between md:justify-center relative bg-black/80 rounded-xl overflow-hidden
                            ${pWin ? 'border-amber-500 shadow-[0_0_40px_rgba(245,158,11,0.3)] scale-100 md:scale-105 z-10' : tie ? 'border-stone-700 opacity-80' : 'border-orange-900/50 opacity-60 grayscale'}
                        `}>
                            {/* Background Glow */}
                            <div className={`absolute inset-0 opacity-20 ${pWin ? 'bg-amber-600' : 'bg-stone-900'}`}></div>
                            
                            <span className="relative z-10 text-[10px] text-stone-400 uppercase tracking-[0.3em] md:mb-6 md:border-b border-white/10 pb-2">{loc.name}</span>
                            <div className={`relative z-10 text-xl md:text-3xl font-serif font-black md:mb-4 ${pWin ? 'text-amber-400' : 'text-stone-500'}`}>
                                {pWin ? 'VICTORY' : tie ? 'DRAW' : 'DEFEAT'}
                            </div>
                            <div className="relative z-10 text-2xl md:text-4xl font-mono text-white font-bold tracking-tighter">
                                {loc.playerScore} <span className="text-stone-600 mx-2">-</span> {loc.opponentScore}
                            </div>
                        </div>
                     );
                })}
              </div>
              
              <button onClick={() => { playSound('UI_CLICK'); handleGameEnd(); }} className="mt-10 md:mt-20 group relative px-8 py-4 md:px-12 md:py-5 bg-stone-900 overflow-hidden rounded shadow-2xl border border-amber-800">
                  <div className="absolute inset-0 w-3 bg-amber-600 transition-all duration-[250ms] ease-out group-hover:w-full opacity-20"></div>
                  <span className="relative text-amber-500 group-hover:text-amber-100 font-serif font-bold tracking-[0.3em] text-sm md:text-lg uppercase transition-colors">
                      Return to Camp
                  </span>
              </button>
          </div>
      )}

    </div>
  );
}
