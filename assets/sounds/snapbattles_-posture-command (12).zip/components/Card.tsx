
import React from 'react';
import { CardData, PlayedCard, Posture, CardAffinity } from '../types';

interface CardProps {
  data: CardData | PlayedCard;
  onClick?: () => void;
  isSelected?: boolean;
  isPlayable?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showBack?: boolean;
  disableGrayscale?: boolean; // New prop to force color
  isDestroyed?: boolean; // NEW: Triggers destruction animation
}

// Sophisticated Design System
const AFFINITY_STYLES: Record<CardAffinity, { 
    // The main ambient glow gradient (Radial feel)
    bgGradient: string;
    // The metallic border color
    borderColor: string;
    // The glow around the card
    shadowColor: string;
    // Accent colors for text/icons
    accentColor: string;
    // Icon for watermark
    icon: string;
}> = {
    Standard: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-700 via-slate-900 to-black",
        borderColor: "border-slate-500",
        shadowColor: "shadow-slate-500/30",
        accentColor: "text-slate-200",
        icon: "⚔️"
    },
    Fire: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-red-800 via-[#2a0a0a] to-black",
        borderColor: "border-red-600",
        shadowColor: "shadow-red-500/30",
        accentColor: "text-red-100",
        icon: "🔥"
    },
    Ice: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-800 via-[#05181f] to-black",
        borderColor: "border-cyan-500",
        shadowColor: "shadow-cyan-400/30",
        accentColor: "text-cyan-100",
        icon: "❄️"
    },
    Nature: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800 via-[#051f0a] to-black",
        borderColor: "border-emerald-500",
        shadowColor: "shadow-emerald-400/30",
        accentColor: "text-emerald-100",
        icon: "🌿"
    },
    Dark: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900 via-[#0a0214] to-black",
        borderColor: "border-indigo-600",
        shadowColor: "shadow-indigo-500/30",
        accentColor: "text-indigo-200",
        icon: "💀"
    },
    Light: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-600 via-[#2e1a03] to-black",
        borderColor: "border-amber-400",
        shadowColor: "shadow-amber-400/40",
        accentColor: "text-amber-50",
        icon: "✨"
    },
    Earth: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-stone-600 via-[#292524] to-black",
        borderColor: "border-stone-500",
        shadowColor: "shadow-stone-400/30",
        accentColor: "text-stone-200",
        icon: "🪨"
    },
    Wind: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sky-700 via-[#0f172a] to-black",
        borderColor: "border-sky-400",
        shadowColor: "shadow-sky-400/30",
        accentColor: "text-sky-100",
        icon: "💨"
    },
    Electric: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-violet-700 via-[#1a0836] to-black",
        borderColor: "border-violet-500",
        shadowColor: "shadow-violet-400/40",
        accentColor: "text-violet-100",
        icon: "⚡"
    },
    Toxic: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-lime-700 via-[#142104] to-black",
        borderColor: "border-lime-500",
        shadowColor: "shadow-lime-400/30",
        accentColor: "text-lime-100",
        icon: "☣️"
    },
    Cosmic: { 
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-fuchsia-800 via-[#26051d] to-black",
        borderColor: "border-fuchsia-600",
        shadowColor: "shadow-fuchsia-500/40",
        accentColor: "text-pink-100",
        icon: "🌌"
    },
    Aquatic: {
        bgGradient: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-teal-700 via-[#061f1f] to-black",
        borderColor: "border-teal-500",
        shadowColor: "shadow-teal-400/30",
        accentColor: "text-teal-100",
        icon: "🌊"
    },
};

const Card: React.FC<CardProps> = ({ 
  data, 
  onClick, 
  isSelected = false, 
  isPlayable = true,
  size = 'md',
  showBack = false,
  disableGrayscale = false,
  isDestroyed = false
}) => {
  const isPlayed = 'owner' in data;
  const mode = isPlayed ? (data as PlayedCard).mode : null;
  const affinity = data.affinity || 'Standard';
  const styles = AFFINITY_STYLES[affinity];
  
  // Sizing Logic
  // Using slightly different aspect ratios or scaling if needed, but keeping consistent classes
  let sizeClasses = "w-32 h-48"; // Default
  let textScale = "text-xs";
  let headerHeight = "h-7";
  
  if (size === 'sm') {
      sizeClasses = "w-16 h-24";
      textScale = "text-[8px]"; // Smaller text for board cards
      headerHeight = "h-5";
  }
  if (size === 'lg') {
      sizeClasses = "w-64 h-96";
      textScale = "text-sm";
      headerHeight = "h-10";
  }

  // Interactive State Styles
  let stateStyles = "";
  let glowEffect = "";
  let zIndex = "z-0";

  // Destruction Effect Style
  const destructionStyle = isDestroyed 
    ? "grayscale brightness-50 contrast-125 sepia-100 opacity-60 transition-all duration-[2000ms] scale-90 border-red-950 shadow-none pointer-events-none" 
    : "";

  if (showBack) {
     return (
        <div className={`${sizeClasses} rounded-xl bg-stone-900 border-2 border-stone-800 flex items-center justify-center relative shadow-2xl overflow-hidden group`}>
            {/* Pattern Overlay */}
            <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]"></div>
            <div className="w-12 h-12 rounded-full border-2 border-stone-700 flex items-center justify-center bg-black/40 shadow-inner">
                <div className="w-6 h-6 rounded-full bg-stone-800"></div>
            </div>
            <div className="absolute inset-0 ring-1 ring-inset ring-white/5 rounded-xl pointer-events-none"></div>
        </div>
     );
  }

  if (isPlayed) {
    zIndex = "z-10";
    // Active on board: Highlight based on posture
    // UPDATED COLORS: Attack = Orange, Defense = Violet/Purple
    if (mode === 'ATACK') {
        // Orange Glow
        glowEffect = "shadow-[0_0_10px_rgba(249,115,22,0.4)] border-orange-600/80 ring-1 ring-orange-900";
        stateStyles = "scale-100";
    } else {
        // Violet Glow
        glowEffect = "shadow-[0_0_10px_rgba(139,92,246,0.4)] border-violet-600/80 ring-1 ring-violet-900";
        stateStyles = "scale-100";
    }
  } else {
    // In Hand
    if (isSelected) {
        stateStyles = "-translate-y-16 scale-125 z-50 rotate-0";
        glowEffect = `shadow-[0_0_30px_rgba(255,255,255,0.3)] ${styles.borderColor} ring-2 ring-amber-400/50`;
    } else if (isPlayable) {
        stateStyles = "hover:-translate-y-4 hover:scale-110 hover:z-40 cursor-grab active:cursor-grabbing";
        glowEffect = `shadow-xl ${styles.borderColor} group-hover:${styles.shadowColor}`;
    } else {
        stateStyles = disableGrayscale ? "" : "opacity-60 scale-95 grayscale";
        glowEffect = "border-stone-800 shadow-none";
    }
  }

  // Handle Drag Start
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
      if (isPlayable && !isPlayed) {
          e.dataTransfer.setData("text/plain", data.id);
          e.dataTransfer.effectAllowed = "move";
          // Opacity visual cue
          e.currentTarget.style.opacity = '0.5';
      } else {
          e.preventDefault();
      }
  };

  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
      e.currentTarget.style.opacity = '1';
  };

  return (
    <div 
        draggable={!isPlayed && isPlayable && !isDestroyed}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onClick={(e) => {
            if (onClick && !isDestroyed) {
                e.stopPropagation();
                onClick();
            }
        }}
        className={`
            ${sizeClasses} ${stateStyles} ${textScale} ${destructionStyle}
            relative rounded-xl transition-all duration-300 ease-out
            border-[1px] ${glowEffect}
            flex flex-col overflow-hidden select-none origin-bottom group bg-black
        `}
    >
        {/* DESTRUCTION ASH OVERLAY */}
        {isDestroyed && (
             <div className="absolute inset-0 z-50 bg-[url('https://www.transparenttextures.com/patterns/black-felt.png')] opacity-60 mix-blend-multiply pointer-events-none animate-pulse"></div>
        )}

        {/* 1. BACKGROUND LAYER: Deep Radial Gradient */}
        <div className={`absolute inset-0 ${styles.bgGradient} opacity-90`}></div>

        {/* 2. NOISE TEXTURE (Optional CSS trick if simple) - Adding subtle grain via opacity */}
        <div className="absolute inset-0 bg-white/5 mix-blend-overlay opacity-20 pointer-events-none"></div>

        {/* 3. SHIMMER EFFECT (Premium Gloss) */}
        {!showBack && !isDestroyed && (
             <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden rounded-xl">
                 <div className="absolute -top-[100%] -left-[100%] w-[300%] h-[300%] bg-gradient-to-r from-transparent via-white/10 to-transparent transform rotate-45 animate-shimmer"></div>
             </div>
        )}

        {/* 4. CARD CONTENT */}
        <div className="relative z-10 flex flex-col h-full">
            
            {/* HEADER: Glassmorphism */}
            <div className={`${headerHeight} flex items-center justify-between px-1.5 border-b border-white/10 bg-black/40 backdrop-blur-sm shadow-sm`}>
                {/* Mana Crystal - UPDATED TO NEON VIOLET */}
                <div className={`
                    ${size === 'sm' ? 'w-3.5 h-3.5 text-[8px]' : 'w-5 h-5 md:w-6 md:h-6'} 
                    rounded-full flex items-center justify-center font-bold text-white shadow-lg border border-white/20
                    ${isPlayable || isPlayed || disableGrayscale ? 'bg-gradient-to-br from-violet-500 to-violet-900' : 'bg-stone-700'}
                `}>
                    <span className="drop-shadow-md">{data.power_cost}</span>
                </div>
                
                {/* Name */}
                {size !== 'sm' && (
                    <div className={`flex-1 text-center font-serif font-bold tracking-wide truncate px-2 ${styles.accentColor} drop-shadow-md`}>
                        {data.name}
                    </div>
                )}

                {/* POSTURE ICON (On Board) - Updated Position: Parallel to Cost */}
                {mode && (
                    <div className={`
                        ${size === 'sm' ? 'w-3.5 h-3.5' : 'w-6 h-6'} 
                        rounded-full flex items-center justify-center 
                        ${mode === 'ATACK' 
                            ? 'bg-orange-950 border border-orange-500 text-orange-200' 
                            : 'bg-violet-950 border border-violet-500 text-violet-200'}
                        shadow-md ml-auto animate-in zoom-in duration-300
                    `}>
                         <div className={size === 'sm' ? 'text-[8px] leading-none' : 'text-xs'}>{mode === 'ATACK' ? '⚔️' : '🛡️'}</div>
                    </div>
                )}
            </div>

            {/* ARTWORK AREA */}
            <div className="flex-1 relative overflow-hidden bg-transparent transition-colors duration-500">
                {/* The Image - FULLY OPAQUE NOW */}
                <img 
                    src={data.image_url} 
                    alt={data.name} 
                    className="w-full h-full object-cover opacity-100 transition-all duration-500 scale-100 group-hover:scale-105 pointer-events-none" 
                />
                
                {/* Vignette Overlay on Image - REDUCED INTENSITY */}
                <div className="absolute inset-0 shadow-[inset_0_0_10px_rgba(0,0,0,0.5)] pointer-events-none"></div>

                {/* Affinity Watermark (Subtle background icon) */}
                <div className="absolute bottom-1 right-1 text-4xl opacity-10 pointer-events-none mix-blend-overlay">
                    {styles.icon}
                </div>

                {/* SELECTED STATE OVERLAYS */}
                {isSelected && !isPlayed && (
                    <>
                        {/* Top Right "Info" Button - Smaller and unobtrusive */}
                        <div className="absolute top-2 right-2 pointer-events-none animate-in fade-in zoom-in duration-300 z-20">
                             <div className="w-5 h-5 rounded-full bg-black/80 border border-amber-500/60 text-amber-400 flex items-center justify-center shadow-[0_0_10px_rgba(245,158,11,0.5)] backdrop-blur-md">
                                <span className="font-serif font-bold text-[10px] italic">i</span>
                             </div>
                        </div>
                        
                        {/* Bottom Stats Floating */}
                        <div className="absolute bottom-2 inset-x-2 flex justify-between items-end pointer-events-none">
                            <div className="bg-black/80 backdrop-blur-md border border-orange-500/50 rounded p-1 flex flex-col items-center shadow-lg transform -rotate-3">
                                <span className="text-[10px] text-stone-400 uppercase leading-none">Atk</span>
                                <span className="text-xl font-black text-orange-500 leading-none filter drop-shadow-md">{data.stats.atack}</span>
                            </div>
                            <div className="bg-black/80 backdrop-blur-md border border-violet-500/50 rounded p-1 flex flex-col items-center shadow-lg transform rotate-3">
                                <span className="text-[10px] text-stone-400 uppercase leading-none">Def</span>
                                <span className="text-xl font-black text-violet-500 leading-none filter drop-shadow-md">{data.stats.defense}</span>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* FOOTER: Glassmorphism Stats (Visible when NOT selected) */}
            {!isSelected && (
                <div className={`relative z-10 bg-black/60 backdrop-blur-md border-t border-white/10 ${size === 'sm' ? 'p-0.5' : 'p-1.5'} flex justify-between items-center`}>
                    <div className="flex items-center gap-0.5">
                        <span className={`${size === 'sm' ? 'text-[8px]' : 'text-xs'} opacity-70`}>⚔️</span>
                        <span className={`${size === 'sm' ? 'text-[9px]' : 'text-sm'} font-bold ${mode === 'ATACK' ? 'text-orange-400' : 'text-stone-300'}`}>{data.stats.atack}</span>
                    </div>
                    
                    {/* Tiny Class Text if space permits */}
                    {size !== 'sm' && (
                        <div className="text-[8px] text-stone-500 uppercase tracking-tighter truncate max-w-[60px]">
                            {data.class.split('/')[0]}
                        </div>
                    )}

                    <div className="flex items-center gap-0.5">
                        <span className={`${size === 'sm' ? 'text-[9px]' : 'text-sm'} font-bold ${mode === 'DEFENSE' ? 'text-violet-400' : 'text-stone-300'}`}>{data.stats.defense}</span>
                        <span className={`${size === 'sm' ? 'text-[8px]' : 'text-xs'} opacity-70`}>🛡️</span>
                    </div>
                </div>
            )}
        </div>

        {/* 5. INNER RING GLOW (Simulates magical edge) */}
        <div className={`absolute inset-0 rounded-xl ring-1 ring-inset ring-white/10 pointer-events-none z-30`}></div>
    </div>
  );
};

export default Card;
