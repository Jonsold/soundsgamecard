
import React from 'react';
import { CardData, CardAffinity } from '../types';

interface CardInspectorProps {
  card: CardData;
  onClose: () => void;
}

// INSPECTOR STYLES - Updated to use Deep Radial Gradients and Glassmorphism
// Mirroring the logic from Card.tsx but for full-screen layout
const INSPECTOR_STYLES: Record<CardAffinity, { 
    bgGradient: string; // The main background
    border: string; 
    textAccent: string;
    glassPanel: string; // Style for stats/text containers
    glowColor: string;
}> = {
    Standard: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-slate-800 via-slate-950 to-black", 
        border: "border-slate-600", 
        textAccent: "text-slate-200", 
        glassPanel: "bg-slate-900/60 border-slate-700",
        glowColor: "shadow-slate-500/20"
    },
    Fire: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-red-900 via-[#1a0505] to-black", 
        border: "border-red-700", 
        textAccent: "text-red-200", 
        glassPanel: "bg-red-950/40 border-red-800",
        glowColor: "shadow-red-500/30"
    },
    Ice: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-cyan-900 via-[#020d12] to-black", 
        border: "border-cyan-600", 
        textAccent: "text-cyan-200", 
        glassPanel: "bg-cyan-950/40 border-cyan-800",
        glowColor: "shadow-cyan-400/30"
    },
    Nature: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-emerald-900 via-[#021405] to-black", 
        border: "border-emerald-600", 
        textAccent: "text-emerald-200", 
        glassPanel: "bg-emerald-950/40 border-emerald-800",
        glowColor: "shadow-emerald-400/30"
    },
    Dark: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-indigo-900 via-[#0a0214] to-black", 
        border: "border-indigo-600", 
        textAccent: "text-indigo-200", 
        glassPanel: "bg-indigo-950/40 border-indigo-800",
        glowColor: "shadow-indigo-500/40"
    },
    Light: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-amber-700 via-[#1f1202] to-black", 
        border: "border-amber-500", 
        textAccent: "text-amber-100", 
        glassPanel: "bg-amber-950/40 border-amber-800",
        glowColor: "shadow-amber-400/40"
    },
    Earth: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-stone-700 via-[#1c1917] to-black", 
        border: "border-stone-500", 
        textAccent: "text-stone-300", 
        glassPanel: "bg-stone-900/60 border-stone-700",
        glowColor: "shadow-stone-500/30"
    },
    Wind: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-sky-800 via-[#0f172a] to-black", 
        border: "border-sky-500", 
        textAccent: "text-sky-200", 
        glassPanel: "bg-sky-900/40 border-sky-700",
        glowColor: "shadow-sky-400/30"
    },
    Electric: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-violet-800 via-[#110524] to-black", 
        border: "border-violet-600", 
        textAccent: "text-violet-200", 
        glassPanel: "bg-violet-950/40 border-violet-800",
        glowColor: "shadow-violet-400/40"
    },
    Toxic: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-lime-800 via-[#0f1a03] to-black", 
        border: "border-lime-600", 
        textAccent: "text-lime-200", 
        glassPanel: "bg-lime-950/40 border-lime-800",
        glowColor: "shadow-lime-400/30"
    },
    Cosmic: { 
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-fuchsia-900 via-[#1a0314] to-black", 
        border: "border-fuchsia-600", 
        textAccent: "text-pink-200", 
        glassPanel: "bg-fuchsia-950/40 border-fuchsia-800",
        glowColor: "shadow-fuchsia-500/40"
    },
    Aquatic: {
        bgGradient: "bg-[radial-gradient(circle_at_top_left,_var(--tw-gradient-stops))] from-teal-800 via-[#041414] to-black",
        border: "border-teal-600",
        textAccent: "text-teal-200",
        glassPanel: "bg-teal-950/40 border-teal-800",
        glowColor: "shadow-teal-500/40"
    },
};

export default function CardInspector({ card, onClose }: CardInspectorProps) {
  const affinity = card.affinity || 'Standard';
  const style = INSPECTOR_STYLES[affinity];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 backdrop-blur-xl p-4 animate-in fade-in duration-200" onClick={onClose}>
      <div 
        className={`
            relative w-full max-w-sm md:max-w-5xl h-[85vh] md:h-[85vh] 
            ${style.bgGradient} border-2 ${style.border} ${style.glowColor} shadow-[0_0_50px_rgba(0,0,0,0.5)]
            rounded-2xl overflow-hidden flex flex-col md:flex-row 
            animate-in zoom-in-95 duration-300 ring-1 ring-white/10
        `}
        onClick={(e) => e.stopPropagation()} 
      >
        
        {/* Shimmer Effect on the whole container boundary */}
        <div className="absolute inset-0 z-20 pointer-events-none rounded-2xl overflow-hidden">
             <div className="absolute -top-[100%] -left-[100%] w-[300%] h-[300%] bg-gradient-to-r from-transparent via-white/5 to-transparent transform rotate-45 animate-shimmer"></div>
        </div>

        {/* Close Button */}
        <button 
            onClick={onClose}
            className="absolute top-4 right-4 z-50 bg-black/40 hover:bg-white/10 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold border border-white/20 transition-all backdrop-blur-md"
        >
            ✕
        </button>

        {/* Left Side: Art & Main Stats */}
        <div className="w-full md:w-3/5 h-64 md:h-full relative group bg-black shrink-0">
            <img 
                src={card.image_url} 
                alt={card.name} 
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-all duration-700 scale-100 group-hover:scale-105"
            />
            
            {/* Dark Vignette Overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,black_120%)] pointer-events-none"></div>

            {/* Cost Bubble */}
            <div className="absolute top-4 left-4 md:top-8 md:left-8">
                <div className={`w-12 h-12 md:w-16 md:h-16 rounded-full bg-black/60 backdrop-blur-md border-2 ${style.border} ${style.textAccent} font-black flex items-center justify-center text-2xl md:text-4xl shadow-2xl z-30`}>
                    {card.power_cost}
                </div>
            </div>
            
            {/* Stats Overlay on Image */}
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black via-black/80 to-transparent p-6 md:p-10 flex justify-between items-end">
                 <div className="flex flex-col items-center transform -rotate-3 transition-transform hover:rotate-0">
                    <span className="text-2xl md:text-4xl mb-1 md:mb-2 drop-shadow-[0_0_10px_rgba(255,0,0,0.5)]">⚔️</span>
                    {/* Attack Text: Orange Gradient */}
                    <span className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-orange-300 to-orange-600 drop-shadow-sm">{card.stats.atack}</span>
                 </div>
                 <div className="flex flex-col items-center transform rotate-3 transition-transform hover:rotate-0">
                    <span className="text-2xl md:text-4xl mb-1 md:mb-2 drop-shadow-[0_0_10px_rgba(139,92,246,0.5)]">🛡️</span>
                    {/* Defense Text: Violet Gradient */}
                    <span className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-violet-300 to-violet-600 drop-shadow-sm">{card.stats.defense}</span>
                 </div>
            </div>
        </div>

        {/* Right Side: Details - Glassmorphism Panel */}
        <div className="w-full md:w-2/5 p-6 md:p-8 flex flex-col justify-between relative z-30 overflow-hidden">
            {/* Content Container */}
            <div className="h-full flex flex-col">
                <div className="border-b border-white/10 pb-4 mb-6">
                    <h2 className={`text-3xl md:text-5xl font-black ${style.textAccent} leading-tight mb-3 font-serif drop-shadow-md tracking-wide truncate`}>
                        {card.name}
                    </h2>
                    <div className="flex gap-3">
                        <div className={`inline-block px-3 py-1 rounded-sm border ${style.border} bg-black/30 backdrop-blur-sm text-xs font-bold ${style.textAccent} uppercase tracking-[0.2em] shadow-sm`}>
                            {affinity}
                        </div>
                        <div className="inline-block px-3 py-1 rounded-sm border border-stone-700 bg-stone-900/50 backdrop-blur-sm text-xs font-bold text-stone-400 uppercase tracking-[0.2em]">
                            {card.class}
                        </div>
                    </div>
                </div>

                <div className="space-y-4 md:space-y-6 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                    <div className={`${style.glassPanel} p-4 md:p-6 rounded-lg backdrop-blur-sm hover:bg-white/5 transition-colors group`}>
                        {/* On Attack: Orange Text */}
                        <h3 className="text-orange-400 text-xs font-bold uppercase mb-2 flex items-center gap-2 tracking-[0.2em] border-b border-white/5 pb-2">
                            <span>⚔️</span> On Attack
                        </h3>
                        <p className="text-stone-300 text-base md:text-lg font-medium leading-relaxed font-serif italic group-hover:text-white transition-colors">
                            "{card.abilities.on_attack}"
                        </p>
                    </div>

                    <div className={`${style.glassPanel} p-4 md:p-6 rounded-lg backdrop-blur-sm hover:bg-white/5 transition-colors group`}>
                        {/* On Defense: Violet Text */}
                        <h3 className="text-violet-400 text-xs font-bold uppercase mb-2 flex items-center gap-2 tracking-[0.2em] border-b border-white/5 pb-2">
                            <span>🛡️</span> On Defense
                        </h3>
                        <p className="text-stone-300 text-base md:text-lg font-medium leading-relaxed font-serif italic group-hover:text-white transition-colors">
                            "{card.abilities.on_defense}"
                        </p>
                    </div>
                </div>
            
                <div className="mt-6 pt-4 border-t border-white/10 flex justify-between items-center text-[10px] text-stone-500 font-mono uppercase">
                    <span>ID: {card.id}</span>
                    <span>Rarity: Common</span>
                </div>
            </div>
        </div>

      </div>
    </div>
  );
}
