
import React, { useState } from 'react';
import { LocationState, PlayedCard, GamePhase } from '../types';
import Card from './Card';

interface LocationProps {
  location: LocationState;
  onSelect: () => void;
  onDropCard?: (cardId: string) => void;
  onInspectCard?: (card: PlayedCard) => void; // New Prop for clicking played cards
  isActiveDrop: boolean;
  gamePhase: GamePhase;
}

const Location: React.FC<LocationProps> = ({ location, onSelect, onDropCard, onInspectCard, isActiveDrop, gamePhase }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  
  // Calculate visual dominance
  const totalScore = location.playerScore + location.opponentScore;
  const playerPercentage = totalScore === 0 ? 50 : (location.playerScore / totalScore) * 100;

  // Determination of Destruction
  const isGameOverOrCelebration = gamePhase === 'GAME_OVER' || gamePhase === 'CELEBRATION';
  const playerWon = location.playerScore > location.opponentScore;
  const opponentWon = location.opponentScore > location.playerScore;

  // Intensity Checks for RED Border
  const isPlayerFull = location.playerCards.length >= 4;
  const isHighIntensity = totalScore >= 25; // "Concentração de poder maior" threshold

  // If game is over:
  // - If Player Won: Opponent cards get destroyed
  // - If Opponent Won: Player cards get destroyed
  // - Tie: No one destroyed (or both? Let's say safe on tie for now)
  const destroyOpponentCards = isGameOverOrCelebration && playerWon;
  const destroyPlayerCards = isGameOverOrCelebration && opponentWon;

  const getBorderColor = () => {
    // 1. Interaction States (Top Priority - Yellow/Amber)
    if (isDragOver) return 'border-amber-400 shadow-[0_0_40px_rgba(245,158,11,0.8)] scale-[1.03] ring-2 ring-amber-300 z-30';
    if (isActiveDrop) return 'border-amber-400 shadow-[0_0_30px_rgba(245,158,11,0.6)] scale-[1.02] z-10';
    
    // 2. High Intensity / Full Capacity (Red - Danger/Max)
    if (isPlayerFull || isHighIntensity) {
        return 'border-red-600 shadow-[0_0_25px_rgba(220,38,38,0.5)] ring-1 ring-red-500/50';
    }

    // 3. Standard Game State (Gold/Orange)
    if (location.playerScore > location.opponentScore) return 'border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.4)] ring-1 ring-amber-400/50';
    
    // Opponent Winning: Orange/Red-Orange
    if (location.opponentScore > location.playerScore) return 'border-orange-600 shadow-[0_0_20px_rgba(234,88,12,0.4)] ring-1 ring-orange-500/50';
    
    // 4. Neutral
    return 'border-stone-600 hover:border-stone-500';
  };

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      if (gamePhase === 'PLANNING' && location.playerCards.length < 4) {
          setIsDragOver(true);
      }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault(); // Necessary to allow dropping
      e.dataTransfer.dropEffect = "move";
      if (gamePhase === 'PLANNING' && location.playerCards.length < 4 && !isDragOver) {
          setIsDragOver(true);
      }
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      
      if (e.currentTarget.contains(e.relatedTarget as Node)) {
          return;
      }
      
      setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragOver(false);
      const cardId = e.dataTransfer.getData("text/plain");
      if (cardId && onDropCard) {
          onDropCard(cardId);
      }
  };

  return (
    <div 
      className={`flex-1 flex flex-col h-full bg-stone-900 border-2 rounded-lg transition-all duration-300 relative overflow-hidden group ${getBorderColor()}`}
      onClick={(e) => {
          e.stopPropagation();
          onSelect();
      }}
      onDragEnter={handleDragEnter}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Background Image Layer - Brightened */}
      <div className="absolute inset-0 z-0 pointer-events-none">
         <img src={location.imageUrl} alt="" className="w-full h-full object-cover opacity-90 transition-transform duration-1000 group-hover:scale-110" />
         
         {/* Strategic Gradients: Dark at top/bottom for cards, transparent in middle for art */}
         <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black/80" />
         
         {/* Shiny Glass Overlay */}
         <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-black/20 pointer-events-none mix-blend-overlay"></div>
      </div>

      {/* Drag Over Overlay Hint - POINTER EVENTS NONE to prevent flickering */}
      {isDragOver && (
          <div className="absolute inset-0 bg-amber-500/20 z-30 flex items-center justify-center animate-pulse backdrop-blur-[1px] pointer-events-none">
              <div className="bg-black/80 px-6 py-3 rounded-lg border-2 border-amber-400 text-amber-300 font-serif font-black text-xl tracking-widest shadow-2xl transform scale-110">
                  DROP TO DEPLOY
              </div>
          </div>
      )}

      {/* Opponent Side */}
      <div className="flex-1 p-2 flex flex-col justify-start items-center gap-[-20px] relative z-10">
        <div className="flex flex-wrap justify-center content-start w-full gap-1">
            {location.opponentCards.map((card) => (
            <div key={card.instanceId} className="-mb-10 z-0 hover:z-10 hover:-translate-y-4 transition-all">
                {/* Pointer events enabled for click */}
                <div className="pointer-events-auto">
                    <Card 
                        data={card} 
                        size="sm" 
                        showBack={!card.revealed} 
                        onClick={() => onInspectCard && onInspectCard(card)}
                        isDestroyed={destroyOpponentCards}
                    />
                </div>
            </div>
            ))}
        </div>
      </div>

      {/* Center Info / Score - Modified to include Name */}
      <div className="flex flex-col items-center justify-center relative z-20 my-1 pointer-events-none gap-1">
        
        {/* The floating score pill */}
        <div className="relative h-8 md:h-10 w-28 md:w-32 bg-black/60 backdrop-blur-md rounded border border-white/10 shadow-xl overflow-hidden flex items-center justify-center">
             {/* Score Bar Background inside the pill */}
            <div className="absolute inset-0 flex opacity-30">
                {/* Opponent Score Bar (Top/Left) - Orange/Red-Orange */}
                <div className="h-full bg-orange-600 transition-all duration-1000" style={{ width: `${100 - playerPercentage}%`}} />
                {/* Player Score Bar (Right/Bottom) - Amber/Gold */}
                <div className="h-full bg-amber-500 transition-all duration-1000" style={{ width: `${playerPercentage}%`}} />
            </div>

            {/* Scores Text */}
            <div className="w-full flex justify-between px-4 text-lg md:text-xl font-black drop-shadow-[0_2px_2px_rgba(0,0,0,1)] relative z-10">
                <span className={location.opponentScore > location.playerScore ? "text-orange-400" : "text-stone-400"}>{location.opponentScore}</span>
                <span className={location.playerScore > location.opponentScore ? "text-amber-400" : "text-stone-400"}>{location.playerScore}</span>
            </div>
        </div>

        {/* LOCATION NAME - Moved to Center to avoid conflict */}
        <div className="bg-black/80 px-3 py-0.5 rounded-full border border-stone-800/50 backdrop-blur-md shadow-lg z-30">
             <span className="text-[9px] md:text-[10px] text-stone-300 font-serif font-bold tracking-widest uppercase drop-shadow-md whitespace-nowrap">
                {location.name}
           </span>
        </div>
      </div>

      {/* Player Side */}
      <div className="flex-1 p-2 flex flex-col justify-end items-center relative z-10">
        <div className="flex flex-wrap justify-center content-end w-full gap-1 z-10">
            {location.playerCards.map((card) => (
            <div key={card.instanceId} className="-mt-10 z-0 hover:z-10 hover:-translate-y-4 transition-all">
                 <div className="pointer-events-auto">
                    <Card 
                        data={card} 
                        size="sm"
                        onClick={() => onInspectCard && onInspectCard(card)} 
                        isDestroyed={destroyPlayerCards}
                    />
                 </div>
            </div>
            ))}
        </div>

        {/* TAP TO PLACE OVERLAY - Pulsing Gold (Click Mode fallback) */}
        {isActiveDrop && !isDragOver && (
            <div className="absolute inset-0 bg-amber-500/10 flex items-center justify-center pointer-events-none z-20 animate-pulse border-2 border-dashed border-amber-400/50 rounded-lg">
                <div className="bg-black/80 px-4 py-2 rounded text-amber-400 font-serif font-bold border border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.6)] text-xs tracking-[0.2em] backdrop-blur-md">
                    DEPLOY
                </div>
            </div>
        )}
      </div>

    </div>
  );
};

export default Location;
