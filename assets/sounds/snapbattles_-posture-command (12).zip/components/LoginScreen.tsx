
import React, { useState, useEffect } from 'react';
import { UserProfile, CardData, CardAffinity } from '../types';
import { CARD_LIBRARY, DECK_SIZE, INITIAL_CARDS_COUNT, INITIAL_POINTS, AVATAR_OPTIONS } from '../constants';
import { auth, db, googleProvider } from '../services/firebase';
import { playSound } from '../services/audioService';

interface LoginScreenProps {
  onLogin: () => void;
}

// Lista de backgrounds para rotação
const BACKGROUNDS = [
  "https://res.cloudinary.com/dokkkdftz/image/upload/v1768619228/Hailuo_Image_com_base_nessa_imagem_sem_per_468767438506885120_resvc1.jpg?q=80&w=2074&auto=format&fit=crop", // Imagem Original (Portal Místico)
  "https://res.cloudinary.com/dokkkdftz/image/upload/v1768620846/Hailuo_Image_sem_seguir_a_imagem_referencia_468774955588853767_ab0lsf.jpg?q=80&w=2074&auto=format&fit=crop", // Floresta Sombria
  "https://res.cloudinary.com/dokkkdftz/image/upload/v1768620729/Hailuo_image_468771693192093701_dboa2g.jpg?q=80&w=2068&auto=format&fit=crop"  // Ruínas Antigas
];

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [summonerName, setSummonerName] = useState('');
  const [selectedAvatarId, setSelectedAvatarId] = useState<string>(AVATAR_OPTIONS[0].id);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Estado para controlar o índice do background atual
  const [bgIndex, setBgIndex] = useState(0);

  // Efeito para rotacionar o background a cada 15 segundos
  useEffect(() => {
    const interval = setInterval(() => {
      setBgIndex((prevIndex) => (prevIndex + 1) % BACKGROUNDS.length);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  // Helper to create initial user profile
  const createNewUserProfile = async (uid: string, name: string, avatarId: string = AVATAR_OPTIONS[0].id) => {
        // Generate random unique cards EXCLUSIVELY from the official CARD_LIBRARY
        const shuffledLib = [...CARD_LIBRARY].sort(() => 0.5 - Math.random());
        const initialCollection = shuffledLib.slice(0, INITIAL_CARDS_COUNT).map(c => c.id);
        const initialDeck = initialCollection.slice(0, DECK_SIZE);

        const newUser: UserProfile = {
            id: uid,
            name: name,
            avatarId: avatarId,
            mainAffinity: 'Standard',
            passwordHash: "hidden", 
            level: 1, 
            wins: 0,
            losses: 0,
            points: INITIAL_POINTS,
            collection: initialCollection,
            currentDeck: initialDeck
        };
        
        await db.collection("users").doc(uid).set(newUser);
  };

  const handleGoogleLogin = async () => {
      playSound('UI_CLICK');
      setError('');
      setLoading(true);

      try {
          const result = await auth.signInWithPopup(googleProvider);
          const user = result.user;

          if (user) {
              // Check if user profile exists
              const doc = await db.collection("users").doc(user.uid).get();
              
              if (!doc.exists) {
                  // Create new profile for Google User
                  const displayName = user.displayName || "Traveler";
                  await createNewUserProfile(user.uid, displayName);
                  playSound('BATTLE_START');
              } else {
                  playSound('UI_CLICK');
              }
              onLogin();
          }
      } catch (err: any) {
          console.error("Google Login Error:", err);
          playSound('ERROR');
          setError('Google Sign-In failed.');
      } finally {
          setLoading(false);
      }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    playSound('UI_CLICK');
    setError('');
    setLoading(true);

    if (!email || !password || (isRegistering && !summonerName)) {
        setError('Complete all mystical fields, Summoner.');
        playSound('ERROR');
        setLoading(false);
        return;
    }

    try {
        if (isRegistering) {
            // FIREBASE AUTH REGISTER
            const userCredential = await auth.createUserWithEmailAndPassword(email, password);
            const user = userCredential.user;
            
            if (user) {
                await createNewUserProfile(user.uid, summonerName, selectedAvatarId);
                playSound('BATTLE_START'); 
                onLogin();
            }
        } else {
            // FIREBASE AUTH LOGIN
            await auth.signInWithEmailAndPassword(email, password);
            playSound('UI_CLICK');
            onLogin();
        }
    } catch (err: any) {
        console.error(err);
        playSound('ERROR');
        setError(err.message || 'The portal remains closed. Check your runes.');
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="h-screen w-screen bg-black flex items-center justify-center p-6 relative overflow-hidden">
      
      {/* Background Layers with Fade Transition */}
      {BACKGROUNDS.map((bg, index) => (
        <div
          key={bg}
          className={`absolute inset-0 bg-cover bg-center transition-opacity duration-[2000ms] ease-in-out ${index === bgIndex ? 'opacity-60' : 'opacity-0'}`}
          style={{ backgroundImage: `url('${bg}')` }}
        />
      ))}
      
      {/* Deep Dark Vignette Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#000000_90%)] z-0"></div>

      {/* Main Login Container - Glassmorphism & Metallic Borders */}
      <div className="max-w-md w-full relative z-10 group">
        
        {/* Glow behind the box */}
        <div className="absolute -inset-1 bg-gradient-to-r from-amber-600 to-purple-600 rounded-lg blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
        
        <div className="bg-black/80 backdrop-blur-xl border border-white/10 p-8 rounded-xl shadow-2xl relative overflow-hidden">
            
            {/* Shimmer on container border/top */}
            <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/50 to-transparent opacity-50"></div>

            <div className="mb-8 relative flex flex-col items-center text-center">
                {/* LOGO ICON REPLACED HERE */}
                <div className="inline-flex mb-4 px-6 py-4 rounded-full bg-black/50 border border-amber-500/30 shadow-[0_0_25px_rgba(245,158,11,0.15)] items-center justify-center gap-5 relative overflow-hidden group/icon">
                     {/* Subtle shimmer behind icons */}
                     <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover/icon:translate-x-[100%] transition-transform duration-1000"></div>
                     
                     <span className="text-4xl filter drop-shadow-[0_0_12px_rgba(220,38,38,0.6)] transform -rotate-12 transition-transform group-hover/icon:-rotate-45 group-hover/icon:scale-110 duration-300">⚔️</span>
                     
                     <div className="w-[1px] h-8 bg-gradient-to-b from-transparent via-stone-500 to-transparent opacity-50"></div>
                     
                     <span className="text-4xl filter drop-shadow-[0_0_12px_rgba(37,99,235,0.6)] transform rotate-12 transition-transform group-hover/icon:rotate-0 group-hover/icon:scale-110 duration-300">🛡️</span>
                </div>

                <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-b from-amber-200 to-amber-700 tracking-tighter rustic-title italic drop-shadow-sm w-full">
                    SNAP BATTLES
                </h1>
                <p className="text-stone-400 text-[10px] uppercase tracking-[0.4em] mt-2 font-bold border-t border-stone-800 pt-2 mx-10 w-full">
                    Real-time Strategy Portal
                </p>
                
                {/* BRANDING */}
                <p className="text-amber-800 text-[8px] font-serif italic tracking-[0.1em] mt-1 opacity-80">
                    by midartai games
                </p>
            </div>

            {/* GOOGLE LOGIN BUTTON */}
            {!isRegistering && (
                <div className="mb-4">
                    <button 
                        onClick={handleGoogleLogin}
                        disabled={loading}
                        className="w-full bg-white text-black hover:bg-stone-200 font-bold py-3 rounded-lg flex items-center justify-center gap-3 transition-colors shadow-lg active:scale-95"
                    >
                        <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5" alt="G" />
                        <span className="text-xs uppercase tracking-wider">Sign in with Google</span>
                    </button>
                    <div className="relative my-4">
                        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-stone-800"></div></div>
                        <div className="relative flex justify-center"><span className="bg-black/80 px-2 text-[10px] text-stone-500 uppercase tracking-widest">Or using Email</span></div>
                    </div>
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
                {isRegistering && (
                    <>
                    <div className="group/input">
                        <label className="block text-[10px] uppercase text-amber-700 font-bold mb-1 tracking-widest ml-1">Choose Your Avatar</label>
                        <div className="grid grid-cols-5 gap-2 mb-4 p-2 bg-black/40 rounded-lg border border-stone-800">
                             {AVATAR_OPTIONS.map(av => (
                                 <div 
                                    key={av.id} 
                                    onClick={() => { playSound('UI_HOVER'); setSelectedAvatarId(av.id); }}
                                    className={`
                                        cursor-pointer aspect-square rounded-full overflow-hidden border-2 transition-all duration-200 relative group/avatar
                                        ${selectedAvatarId === av.id ? 'border-amber-500 scale-110 shadow-[0_0_10px_rgba(245,158,11,0.6)] z-10' : 'border-stone-700 hover:border-stone-400 opacity-60 hover:opacity-100'}
                                    `}
                                 >
                                     <img src={av.url} alt={av.name} className="w-full h-full object-cover" />
                                     {selectedAvatarId === av.id && <div className="absolute inset-0 bg-amber-500/20"></div>}
                                 </div>
                             ))}
                        </div>
                    </div>

                    <div className="group/input">
                        <label className="block text-[10px] uppercase text-amber-700 font-bold mb-1 tracking-widest ml-1 group-focus-within/input:text-amber-500 transition-colors">Character Name</label>
                        <input 
                            type="text" 
                            value={summonerName} 
                            onChange={e => setSummonerName(e.target.value)}
                            className="w-full bg-black/50 border border-stone-800 rounded-lg p-3 text-amber-100 placeholder-stone-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 focus:outline-none transition-all font-serif shadow-inner"
                            placeholder="Sir Gideon"
                        />
                    </div>
                    </>
                )}

                <div className="group/input">
                    <label className="block text-[10px] uppercase text-amber-700 font-bold mb-1 tracking-widest ml-1 group-focus-within/input:text-amber-500 transition-colors">Email Address</label>
                    <input 
                        type="email" 
                        value={email} 
                        onChange={e => setEmail(e.target.value)}
                        className="w-full bg-black/50 border border-stone-800 rounded-lg p-3 text-amber-100 placeholder-stone-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 focus:outline-none transition-all font-serif shadow-inner"
                        placeholder="summoner@realm.com"
                    />
                </div>

                <div className="group/input">
                    <label className="block text-[10px] uppercase text-amber-700 font-bold mb-1 tracking-widest ml-1 group-focus-within/input:text-amber-500 transition-colors">Portal Key</label>
                    <input 
                        type="password" 
                        value={password} 
                        onChange={e => setPassword(e.target.value)}
                        className="w-full bg-black/50 border border-stone-800 rounded-lg p-3 text-amber-100 placeholder-stone-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 focus:outline-none transition-all font-serif shadow-inner"
                        placeholder="••••••••"
                    />
                </div>

                {error && (
                    <div className="bg-red-950/30 border border-red-900/50 p-2 rounded text-red-400 text-[10px] text-center font-bold uppercase tracking-wide animate-pulse">
                        ⚠️ {error}
                    </div>
                )}

                <button 
                    type="submit"
                    disabled={loading}
                    className={`
                        w-full relative overflow-hidden group
                        bg-gradient-to-b from-amber-700 to-amber-900 
                        hover:from-amber-600 hover:to-amber-800
                        text-white font-serif font-bold py-4 rounded-lg 
                        shadow-[0_4px_20px_rgba(0,0,0,0.5)] 
                        border-t border-amber-500/50 border-b border-black/50
                        transition-all active:scale-[0.98] tracking-widest uppercase text-xs
                        ${loading ? 'opacity-70 cursor-wait' : ''}
                    `}
                >
                    {/* Shimmer Effect Inside Button */}
                    <div className="absolute top-0 -inset-full h-full w-1/2 z-5 block transform -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-20 group-hover:animate-shimmer" />
                    
                    <span className="relative z-10 flex items-center justify-center gap-2">
                        {loading ? (
                            <><span>🔮</span> <span>Attuning...</span></>
                        ) : isRegistering ? (
                            <><span>✨</span> <span>Inscribe & Enter</span></>
                        ) : (
                            <><span>⚡</span> <span>Enter Realm</span></>
                        )}
                    </span>
                </button>
            </form>

            <div className="mt-6 text-center border-t border-white/5 pt-4">
                <button 
                    onClick={() => { playSound('UI_CLICK'); setIsRegistering(!isRegistering); }}
                    className="text-stone-500 hover:text-amber-400 text-[10px] font-bold uppercase tracking-[0.2em] transition-colors"
                >
                    {isRegistering ? '← Back to Login' : 'Create Your Character!'}
                </button>
            </div>
        </div>
      </div>
    </div>
  );
}
