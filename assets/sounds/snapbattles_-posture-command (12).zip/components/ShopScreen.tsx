
import React, { useState } from 'react';
import { CardData, UserProfile } from '../types';
import Card from './Card';
import { db, auth } from '../services/firebase';
import { playSound } from '../services/audioService';

interface ShopScreenProps {
  library: CardData[];
  profile: UserProfile;
  onBack: () => void;
}

export default function ShopScreen({ library, profile, onBack }: ShopScreenProps) {
  const [purchaseSuccess, setPurchaseSuccess] = useState<string | null>(null);

  // Filter out cards user already has, or let them buy duplicates? 
  // The logic implies "buying cards", usually implies getting more.
  // We'll show a random selection of 10 cards from the library to simulate a "daily shop" or rotating stock,
  // or just show the whole library for this iteration. Let's show all for now but sorted.
  const shopInventory = [...library].sort((a,b) => (calculatePrice(a) - calculatePrice(b)));

  function calculatePrice(card: CardData): number {
      // Basic formula based on prompt: "estimated value by card score"
      // (Attack + Defense) * 10
      return (card.stats.atack + card.stats.defense) * 10;
  }

  const handleBuy = async (card: CardData) => {
      const price = calculatePrice(card);
      if (profile.points < price) {
          playSound('ERROR');
          alert("Not enough gold (points)!");
          return;
      }
      
      if (!auth.currentUser) return;

      const newPoints = profile.points - price;
      const newCollection = [...profile.collection, card.id];

      try {
          await db.collection("users").doc(auth.currentUser.uid).update({
              points: newPoints,
              collection: newCollection
          });
          playSound('COINS');
          setPurchaseSuccess(card.name);
          setTimeout(() => setPurchaseSuccess(null), 2000);
      } catch (e) {
          console.error("Purchase error", e);
          playSound('ERROR');
          alert("Transaction failed.");
      }
  };

  return (
    <div 
        className="h-screen w-screen bg-stone-950 flex flex-col text-stone-200 font-sans bg-cover bg-center"
        style={{ backgroundImage: "url('https://res.cloudinary.com/dokkkdftz/image/upload/v1768619228/Hailuo_Image_com_base_nessa_imagem_sem_per_468767438506885120_resvc1.jpg?q=80&w=2074&auto=format&fit=crop')" }}
    >
        {/* Header */}
        <div className="bg-stone-900/95 p-4 border-b border-amber-900/40 flex justify-between items-center shadow-md z-20 backdrop-blur-md">
            <button onClick={onBack} className="text-stone-500 hover:text-amber-500 font-serif font-bold text-xs uppercase tracking-widest">
                ← Back
            </button>
            <div className="flex flex-col items-center">
                 <h1 className="text-2xl font-black font-serif text-amber-500 tracking-wider rustic-title">MERCHANT</h1>
                 <span className="text-[10px] uppercase text-stone-500 tracking-[0.3em]">Rare Artifacts</span>
            </div>
            <div className="bg-black/50 border border-amber-600/30 px-4 py-2 rounded flex items-center gap-2">
                 <span className="text-amber-400 font-bold text-lg">{profile.points}</span>
                 <span className="text-[10px] uppercase text-amber-700 font-bold">Points</span>
            </div>
        </div>

        {/* Success Notification */}
        {purchaseSuccess && (
             <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-green-900/90 border border-green-500 text-white px-8 py-3 rounded-full z-[300] shadow-[0_0_30px_rgba(34,197,94,0.4)] animate-bounce flex items-center gap-2 backdrop-blur-md">
                <span>✨</span> Purchased {purchaseSuccess}!
            </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-10 relative z-10">
            <div className="absolute inset-0 bg-black/70 pointer-events-none fixed"></div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 relative z-10">
                {shopInventory.map(card => {
                    const price = calculatePrice(card);
                    const canAfford = profile.points >= price;
                    const ownedCount = profile.collection.filter(id => id === card.id).length;

                    return (
                        <div key={card.id} className="bg-stone-900/80 border border-stone-700 rounded-lg overflow-hidden flex flex-row group hover:border-amber-500 transition-all shadow-xl backdrop-blur-sm">
                             <div className="w-1/3 relative">
                                  <div className="absolute inset-0">
                                     <img src={card.image_url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                  </div>
                             </div>
                             <div className="flex-1 p-3 flex flex-col justify-between">
                                 <div>
                                     <h3 className="font-serif font-bold text-amber-100 text-sm truncate">{card.name}</h3>
                                     <p className="text-[10px] text-stone-400 uppercase tracking-widest mb-2">{card.class}</p>
                                     <div className="flex gap-2 text-xs mb-2">
                                         {/* Updated Colors here */}
                                         <span className="text-orange-400 font-bold">⚔️ {card.stats.atack}</span>
                                         <span className="text-violet-400 font-bold">🛡️ {card.stats.defense}</span>
                                     </div>
                                 </div>
                                 
                                 <div className="flex justify-between items-end">
                                     <div className="text-[10px] text-stone-500">Owned: {ownedCount}</div>
                                     <button 
                                        onClick={() => handleBuy(card)}
                                        disabled={!canAfford}
                                        className={`
                                            px-4 py-1.5 rounded-sm font-bold text-xs uppercase tracking-wide border transition-all
                                            ${canAfford 
                                                ? 'bg-amber-800 text-amber-100 border-amber-600 hover:bg-amber-600 hover:shadow-[0_0_15px_rgba(245,158,11,0.4)]' 
                                                : 'bg-stone-800 text-stone-600 border-stone-700 cursor-not-allowed'}
                                        `}
                                     >
                                         {price} Pts
                                     </button>
                                 </div>
                             </div>
                        </div>
                    );
                })}
            </div>
        </div>

    </div>
  );
}
