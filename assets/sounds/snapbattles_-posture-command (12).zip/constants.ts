
import { CardData, LocationState, PlayerRank, CardAffinity } from './types';

export const MAX_TURNS = 6;
export const LOCATIONS_COUNT = 3;
export const DECK_SIZE = 12;

// Economy Constants
export const POINTS_WIN = 20;
export const POINTS_LOSS = 10; 
export const POINTS_RETREAT = 20; 
export const INITIAL_CARDS_COUNT = 30; // Grants a good starter set
export const INITIAL_POINTS = 100;

// Rank Definitions
export const RANKS: Record<number, PlayerRank> = {
    1: 'Aliado',
    2: 'Comandante',
    3: 'Campeão',
    4: 'General',
    5: 'Rei',
    6: 'Rei Supremo'
};

// Visual Styles for Ranks (Borders & Glows)
export const RANK_STYLES: Record<number, string> = {
    1: 'border-stone-600 shadow-stone-600/50 text-stone-400 bg-stone-800', // Aliado (Stone/Bronze)
    2: 'border-slate-300 shadow-slate-300/50 text-slate-200 bg-slate-800', // Comandante (Silver)
    3: 'border-amber-400 shadow-amber-400/50 text-amber-400 bg-amber-950', // Campeão (Gold)
    4: 'border-cyan-400 shadow-cyan-400/60 text-cyan-300 bg-cyan-950', // General (Platinum/Cyan)
    5: 'border-fuchsia-500 shadow-fuchsia-500/70 text-fuchsia-300 bg-fuchsia-950', // Rei (Diamond/Purple)
    6: 'border-red-600 shadow-red-600/80 text-red-500 bg-red-950 animate-pulse' // Rei Supremo (Legendary)
};

export const AFFINITY_LIST: CardAffinity[] = [
    'Standard', 'Fire', 'Ice', 'Nature', 'Dark', 'Light', 'Earth', 'Wind', 'Electric', 'Toxic', 'Cosmic', 'Aquatic'
];

// 12 AVATAR OPTIONS FOR PLAYERS (Updated with new Art)
export const AVATAR_OPTIONS = [
    { id: 'av_1', name: 'High Elf', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670952/Hailuo_Image_art_game_Handsome_high_elf_mal_468981481784074240_yt2mpk.jpg' },
    { id: 'av_2', name: 'Necromancer', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670800/Hailuo_image_468981519201456137_tcx7ly.jpg' },
    { id: 'av_3', name: 'Knight', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670801/Hailuo_image_468981603922247690_nxlhym.jpg' },
    { id: 'av_4', name: 'Archmage', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670937/Hailuo_image_468983453685764097_braaun.jpg' },
    { id: 'av_5', name: 'Orc Warlord', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670803/Hailuo_image_468982192181776391_jih8jd.jpg' },
    { id: 'av_6', name: 'Ranger', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670939/Hailuo_image_468983561177444353_wmnaam.jpg' },
    { id: 'av_7', name: 'Infernal', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670942/Hailuo_image_468984011775688707_hlscuz.jpg' },
    { id: 'av_8', name: 'Lightbringer', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670944/Hailuo_image_468984156382740484_ayelwc.jpg' },
    { id: 'av_9', name: 'Sorceress', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670945/Hailuo_image_468984341007577097_uorve3.jpg' },
    { id: 'av_10', name: 'Paladin', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670947/Hailuo_Image_art_game_Attractive_human_pala_468981562197291017_qutkrv.jpg' },
    { id: 'av_11', name: 'Valkyrie', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670949/Hailuo_Image_art_game_Beautiful_warrior_wo_468982338277736449_j4tjot.jpg' },
    { id: 'av_12', name: 'Dwarf King', url: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768670950/Hailuo_Image_art_game_Charismatic_dwarf_kin_468981990783856644_xoexpg.jpg' }
];

export const RANK_AVATARS: Record<number, string> = {
    1: AVATAR_OPTIONS[2].url, // Knight
    2: AVATAR_OPTIONS[9].url, // Paladin
    3: AVATAR_OPTIONS[10].url, // Valkyrie
    4: AVATAR_OPTIONS[0].url, // High Elf
    5: AVATAR_OPTIONS[11].url, // Dwarf King
    6: AVATAR_OPTIONS[7].url  // Lightbringer (Celestial)
};

// --- PERMANENT CARD LIBRARY (FIXED IDs & URLs) ---
// You can edit Names/Stats in Admin, but these IDs and Images are hardcoded as backup.
export const CARD_LIBRARY: CardData[] = [
  // 1. Warrior of the Throne
  { id: "fixed_001", name: "Warrior of the Throne", class: "Human / Knight", affinity: "Light", power_cost: 5, stats: { atack: 8, defense: 8 }, abilities: { on_attack: "Divine Judgement", on_defense: "Sanctuary" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624543/Hailuo_image_468789226917879817_uiolnc.jpg" },
  
  // 2-87: Imports from your list
  { id: "fixed_002", name: "Mystic Sentinel", class: "Mage", affinity: "Cosmic", power_cost: 4, stats: { atack: 6, defense: 5 }, abilities: { on_attack: "Beam", on_defense: "Shield" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626473/Hailuo_image_468796179505270784_c90o7r.png" },
  { id: "fixed_003", name: "Forest Ranger", class: "Elf", affinity: "Nature", power_cost: 3, stats: { atack: 5, defense: 4 }, abilities: { on_attack: "Shot", on_defense: "Dodge" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626470/Hailuo_image_468796410498199555_rn2tcw.png" },
  { id: "fixed_004", name: "Deep Dweller", class: "Beast", affinity: "Ice", power_cost: 5, stats: { atack: 7, defense: 6 }, abilities: { on_attack: "Strike", on_defense: "Hardens" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626460/Hailuo_image_468796508762345481_ijwfrm.png" },
  { id: "fixed_005", name: "Shadow Stalker", class: "Human / Knight", affinity: "Dark", power_cost: 2, stats: { atack: 6, defense: 2 }, abilities: { on_attack: "Backstab", on_defense: "Hide" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626457/Hailuo_image_468796559744114690_ajfzs7.png" },
  { id: "fixed_006", name: "Ironclad Warrior", class: "Dwarf", affinity: "Earth", power_cost: 4, stats: { atack: 4, defense: 9 }, abilities: { on_attack: "Bash", on_defense: "Fortify" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626456/Hailuo_image_468796627599540229_wfajc7.png" },
  { id: "fixed_007", name: "Storm Caster", class: "Mage", affinity: "Electric", power_cost: 5, stats: { atack: 8, defense: 3 }, abilities: { on_attack: "Bolt", on_defense: "Static" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626453/Hailuo_image_468797024565219334_nw2zh3.png" },
  { id: "fixed_008", name: "Flame Keeper", class: "Mage", affinity: "Fire", power_cost: 3, stats: { atack: 6, defense: 4 }, abilities: { on_attack: "Burn", on_defense: "Warmth" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626453/Hailuo_image_468796676949733380_hsul9v.png" },
  { id: "fixed_009", name: "Wind Walker", class: "Elf", affinity: "Wind", power_cost: 2, stats: { atack: 4, defense: 3 }, abilities: { on_attack: "Gust", on_defense: "Evasion" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626449/Hailuo_image_468797114658877447_e4b3jt.png" },
  { id: "fixed_010", name: "Venom Spit", class: "Beast", affinity: "Toxic", power_cost: 3, stats: { atack: 5, defense: 5 }, abilities: { on_attack: "Poison", on_defense: "Scale" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626439/Hailuo_image_468797159873470471_jxqszw.png" },
  { id: "fixed_011", name: "Crystal Golem", class: "Dwarf", affinity: "Ice", power_cost: 6, stats: { atack: 5, defense: 10 }, abilities: { on_attack: "Smash", on_defense: "Reflect" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626433/Hailuo_image_468797233701609480_up66w7.png" },
  { id: "fixed_012", name: "Sun Cleric", class: "Human", affinity: "Light", power_cost: 2, stats: { atack: 2, defense: 6 }, abilities: { on_attack: "Smite", on_defense: "Heal" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626432/Hailuo_image_468797278626816004_atddnk.png" },
  { id: "fixed_013", name: "Rogue", class: "Human", affinity: "Standard", power_cost: 1, stats: { atack: 4, defense: 1 }, abilities: { on_attack: "Sneak", on_defense: "Run" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626430/Hailuo_image_468797482558115849_waw2xd.png" },
  { id: "fixed_014", name: "Swamp Thing", class: "Beast", affinity: "Toxic", power_cost: 4, stats: { atack: 4, defense: 8 }, abilities: { on_attack: "Grab", on_defense: "Regen" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626429/Hailuo_image_468797514032128009_cq0zou.png" },
  { id: "fixed_015", name: "Dragon Lord", class: "Dragon", affinity: "Fire", power_cost: 6, stats: { atack: 10, defense: 6 }, abilities: { on_attack: "Breath", on_defense: "Scale" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626419/midartai-1768625830376_naripj.png" },
  { id: "fixed_016", name: "Night Elf", class: "Elf", affinity: "Dark", power_cost: 3, stats: { atack: 5, defense: 4 }, abilities: { on_attack: "Aim", on_defense: "Shadow" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626387/Hailuo_image_468797559792001024_m5nqep.png" },
  { id: "fixed_017", name: "Orc Berserker", class: "Orc / Warrior", affinity: "Earth", power_cost: 5, stats: { atack: 9, defense: 2 }, abilities: { on_attack: "Rage", on_defense: "None" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626386/Hailuo_image_468797785634263045_enfq8s.png" },
  { id: "fixed_018", name: "Celestial Guide", class: "Mage", affinity: "Cosmic", power_cost: 4, stats: { atack: 5, defense: 7 }, abilities: { on_attack: "Star", on_defense: "Ward" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626345/Hailuo_image_468793106112270342_exiyp0.png" },
  { id: "fixed_019", name: "Necromancer", class: "Mage", affinity: "Dark", power_cost: 4, stats: { atack: 5, defense: 5 }, abilities: { on_attack: "Drain", on_defense: "Revive" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626342/Hailuo_image_468793308814553088_zlg9mo.png" },
  { id: "fixed_020", name: "Paladin Guard", class: "Human / Knight", affinity: "Light", power_cost: 5, stats: { atack: 4, defense: 8 }, abilities: { on_attack: "Strike", on_defense: "Shield" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626342/Hailuo_image_468793270017282053_qxq518.png" },
  { id: "fixed_021", name: "Wild Beast", class: "Beast", affinity: "Nature", power_cost: 3, stats: { atack: 6, defense: 3 }, abilities: { on_attack: "Claw", on_defense: "Roar" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626341/Hailuo_image_468793796675002377_ikdlh0.png" },
  { id: "fixed_022", name: "Frost Mage", class: "Mage", affinity: "Ice", power_cost: 4, stats: { atack: 7, defense: 4 }, abilities: { on_attack: "Freeze", on_defense: "IceBlock" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626339/Hailuo_image_468793841541509123_rms608.png" },
  { id: "fixed_023", name: "Earth Shaman", class: "Mage", affinity: "Earth", power_cost: 3, stats: { atack: 4, defense: 6 }, abilities: { on_attack: "Rock", on_defense: "Wall" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626338/Hailuo_image_468794004842500100_vmuxxr.png" },
  { id: "fixed_024", name: "Void Entity", class: "Mage", affinity: "Dark", power_cost: 6, stats: { atack: 8, defense: 6 }, abilities: { on_attack: "Consume", on_defense: "Phase" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626336/Hailuo_image_468794117446987778_of0hn0.png" },
  { id: "fixed_025", name: "Lightning Bird", class: "Beast", affinity: "Electric", power_cost: 2, stats: { atack: 5, defense: 1 }, abilities: { on_attack: "Zap", on_defense: "Fly" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626335/Hailuo_image_468794147151085575_jvrggr.png" },
  { id: "fixed_026", name: "Druid Elder", class: "Elf", affinity: "Nature", power_cost: 5, stats: { atack: 3, defense: 8 }, abilities: { on_attack: "Root", on_defense: "Heal" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626334/Hailuo_image_468794176033067008_x0hggd.png" },
  { id: "fixed_027", name: "Royal Knight", class: "Human / Knight", affinity: "Standard", power_cost: 4, stats: { atack: 6, defense: 6 }, abilities: { on_attack: "Charge", on_defense: "Parry" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626331/Hailuo_image_468794216008994821_fqcfyi.png" },
  { id: "fixed_028", name: "Chaos Demon", class: "Mage", affinity: "Fire", power_cost: 6, stats: { atack: 9, defense: 3 }, abilities: { on_attack: "Fire", on_defense: "Fear" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626331/Hailuo_image_468794260200116233_onzwot.png" },
  { id: "fixed_029", name: "Holy Angel", class: "Human", affinity: "Light", power_cost: 6, stats: { atack: 7, defense: 7 }, abilities: { on_attack: "Light", on_defense: "Grace" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626329/Hailuo_image_468794474927583235_oexapg.png" },
  { id: "fixed_030", name: "Witch Doctor", class: "Mage", affinity: "Toxic", power_cost: 3, stats: { atack: 3, defense: 5 }, abilities: { on_attack: "Curse", on_defense: "Brew" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626328/Hailuo_image_468794568636678147_vf9zcs.png" },
  { id: "fixed_031", name: "Sand Warrior", class: "Human / Knight", affinity: "Earth", power_cost: 3, stats: { atack: 5, defense: 4 }, abilities: { on_attack: "Slash", on_defense: "Block" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626326/Hailuo_image_468795174969446405_offjob.png" },
  { id: "fixed_032", name: "Water Nymph", class: "Mage", affinity: "Ice", power_cost: 2, stats: { atack: 2, defense: 5 }, abilities: { on_attack: "Spray", on_defense: "Mist" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626326/Hailuo_image_468795141494734849_gmoqus.png" },
  { id: "fixed_033", name: "Golem Guardian", class: "Dwarf", affinity: "Earth", power_cost: 5, stats: { atack: 3, defense: 9 }, abilities: { on_attack: "Punch", on_defense: "Solid" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626325/Hailuo_image_468795227930927111_mbuz9t.png" },
  { id: "fixed_034", name: "Arcane Archer", class: "Elf", affinity: "Cosmic", power_cost: 4, stats: { atack: 6, defense: 3 }, abilities: { on_attack: "Arrow", on_defense: "Blink" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626324/Hailuo_image_468795399134072840_hk8eke.png" },
  { id: "fixed_035", name: "Skeleton King", class: "Undead", affinity: "Dark", power_cost: 5, stats: { atack: 7, defense: 4 }, abilities: { on_attack: "Slash", on_defense: "Rebuild" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626069/Hailuo_image_468795499025625093_a4cu05.png" },
  { id: "fixed_036", name: "Orc Shaman", class: "Orc / Warrior", affinity: "Fire", power_cost: 3, stats: { atack: 4, defense: 4 }, abilities: { on_attack: "Burn", on_defense: "Totem" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626035/Hailuo_image_468795950005542921_hlmnmr.png" },
  { id: "fixed_037", name: "Beast Master", class: "Human", affinity: "Nature", power_cost: 4, stats: { atack: 5, defense: 5 }, abilities: { on_attack: "Whip", on_defense: "Pet" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626034/Hailuo_image_468796056498929672_hin8th.png" },
  { id: "fixed_038", name: "Spirit Guide", class: "Mage", affinity: "Light", power_cost: 2, stats: { atack: 1, defense: 4 }, abilities: { on_attack: "Flash", on_defense: "Bless" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626033/Hailuo_image_468796093261975556_g519kq.png" },
  { id: "fixed_039", name: "Dark Knight", class: "Human / Knight", affinity: "Dark", power_cost: 5, stats: { atack: 7, defense: 7 }, abilities: { on_attack: "Crush", on_defense: "Spikes" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626031/Hailuo_image_468796179505270784_ald9ex.png" },
  { id: "fixed_040", name: "Elven Scout", class: "Elf", affinity: "Wind", power_cost: 1, stats: { atack: 3, defense: 1 }, abilities: { on_attack: "Shot", on_defense: "Haste" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626031/Hailuo_image_468796410498199555_w6fesp.png" },
  { id: "fixed_041", name: "Sea Monster", class: "Beast", affinity: "Ice", power_cost: 6, stats: { atack: 8, defense: 8 }, abilities: { on_attack: "Bite", on_defense: "Scales" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768626029/Hailuo_image_468796508762345481_oqr02l.png" },
  { id: "fixed_042", name: "Zombie Horde", class: "Zombie", affinity: "Toxic", power_cost: 3, stats: { atack: 4, defense: 2 }, abilities: { on_attack: "Bite", on_defense: "Rise" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625279/Hailuo_image_468792046769479688_j09ph5.jpg" },
  { id: "fixed_043", name: "Ghost", class: "Undead", affinity: "Standard", power_cost: 2, stats: { atack: 3, defense: 3 }, abilities: { on_attack: "Spook", on_defense: "Fade" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625276/Hailuo_image_468792194765492224_qef1mx.png" },
  { id: "fixed_044", name: "Vampire Lord", class: "Undead", affinity: "Dark", power_cost: 5, stats: { atack: 6, defense: 5 }, abilities: { on_attack: "Drain", on_defense: "Mist" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625276/Hailuo_image_468792577025978370_djcthw.png" },
  { id: "fixed_045", name: "Werewolf", class: "Beast", affinity: "Nature", power_cost: 4, stats: { atack: 7, defense: 3 }, abilities: { on_attack: "Claw", on_defense: "Howl" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625275/Hailuo_image_468792608944627717_aznadp.png" },
  { id: "fixed_046", name: "Griffin Rider", class: "Human / Knight", affinity: "Wind", power_cost: 5, stats: { atack: 6, defense: 4 }, abilities: { on_attack: "Dive", on_defense: "Fly" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625273/Hailuo_image_468792640427081736_wpckda.png" },
  { id: "fixed_047", name: "Troll", class: "Orc / Warrior", affinity: "Earth", power_cost: 4, stats: { atack: 5, defense: 6 }, abilities: { on_attack: "Club", on_defense: "Regen" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625272/Hailuo_image_468792693417861126_pkykpx.png" },
  { id: "fixed_048", name: "Harpy", class: "Beast", affinity: "Wind", power_cost: 2, stats: { atack: 4, defense: 1 }, abilities: { on_attack: "Scratch", on_defense: "Fly" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625272/Hailuo_image_468792815560200200_f7dhvb.png" },
  { id: "fixed_049", name: "Minotaur", class: "Beast", affinity: "Earth", power_cost: 5, stats: { atack: 7, defense: 5 }, abilities: { on_attack: "Gore", on_defense: "Tough" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625200/Hailuo_image_468789725675159560_j7lrfp.png" },
  { id: "fixed_050", name: "Cyclops", class: "Beast", affinity: "Standard", power_cost: 6, stats: { atack: 9, defense: 4 }, abilities: { on_attack: "Smash", on_defense: "Stare" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625199/Hailuo_image_468790772959371268_e5boos.png" },
  { id: "fixed_051", name: "Chimera", class: "Beast", affinity: "Fire", power_cost: 6, stats: { atack: 8, defense: 5 }, abilities: { on_attack: "Bite", on_defense: "Roar" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768625074/Hailuo_image_468790902844358664_ttcevs.png" },
  { id: "fixed_052", name: "Banshee", class: "Undead", affinity: "Dark", power_cost: 3, stats: { atack: 5, defense: 2 }, abilities: { on_attack: "Scream", on_defense: "Float" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624969/Hailuo_image_468791166129217542_uguwpi.png" },
  { id: "fixed_053", name: "Dullahan", class: "Undead", affinity: "Dark", power_cost: 4, stats: { atack: 6, defense: 4 }, abilities: { on_attack: "Whip", on_defense: "Ride" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624968/Hailuo_image_468791251143585800_gyu5dg.png" },
  { id: "fixed_054", name: "Lich", class: "Undead", affinity: "Ice", power_cost: 5, stats: { atack: 7, defense: 3 }, abilities: { on_attack: "Freeze", on_defense: "Phylactery" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624965/Hailuo_image_468791814153367561_y0kvbm.png" },
  { id: "fixed_055", name: "Samurai", class: "Human / Knight", affinity: "Standard", power_cost: 4, stats: { atack: 7, defense: 3 }, abilities: { on_attack: "Slash", on_defense: "Focus" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624959/Hailuo_image_468791844515971077_dz0fem.jpg" },
  { id: "fixed_056", name: "Ninja Master", class: "Human", affinity: "Dark", power_cost: 3, stats: { atack: 6, defense: 2 }, abilities: { on_attack: "Shuriken", on_defense: "Log" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624959/Hailuo_image_468791928599126018_iujpt4.jpg" },
  { id: "fixed_057", name: "Monk", class: "Human", affinity: "Standard", power_cost: 2, stats: { atack: 3, defense: 5 }, abilities: { on_attack: "Kick", on_defense: "Meditate" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624958/Hailuo_image_468791960677195781_piuvlb.png" },
  { id: "fixed_058", name: "Viking", class: "Human / Knight", affinity: "Ice", power_cost: 3, stats: { atack: 5, defense: 3 }, abilities: { on_attack: "Axe", on_defense: "Shield" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624700/Hailuo_image_468787235592372234_v9f0ia.png" },
  { id: "fixed_059", name: "Spartan", class: "Human / Knight", affinity: "Earth", power_cost: 3, stats: { atack: 4, defense: 5 }, abilities: { on_attack: "Spear", on_defense: "Wall" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624700/Hailuo_image_468787329154699265_svbvgk.png" },
  { id: "fixed_060", name: "Gladiator", class: "Human / Knight", affinity: "Standard", power_cost: 4, stats: { atack: 6, defense: 4 }, abilities: { on_attack: "Stab", on_defense: "Net" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624699/Hailuo_image_468787699482415111_fij4vx.png" },
  { id: "fixed_061", name: "Pirate", class: "Human", affinity: "Standard", power_cost: 2, stats: { atack: 4, defense: 2 }, abilities: { on_attack: "Pistol", on_defense: "Parrot" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624697/Hailuo_image_468787847948177416_gldzjk.png" },
  { id: "fixed_062", name: "Musketeer", class: "Human", affinity: "Standard", power_cost: 3, stats: { atack: 5, defense: 2 }, abilities: { on_attack: "Shoot", on_defense: "Dodge" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624696/Hailuo_image_468788059362127872_ghd4em.png" },
  { id: "fixed_063", name: "Cowboy", class: "Human", affinity: "Earth", power_cost: 3, stats: { atack: 6, defense: 1 }, abilities: { on_attack: "Draw", on_defense: "Roll" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624693/Hailuo_image_468788168200126471_txm0me.png" },
  { id: "fixed_064", name: "Space Marine", class: "Human", affinity: "Cosmic", power_cost: 5, stats: { atack: 7, defense: 6 }, abilities: { on_attack: "Laser", on_defense: "Armor" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624693/Hailuo_image_468788382323527686_ht3kzh.png" },
  { id: "fixed_065", name: "Cyborg", class: "Human", affinity: "Electric", power_cost: 4, stats: { atack: 6, defense: 5 }, abilities: { on_attack: "Punch", on_defense: "Metal" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624692/Hailuo_image_468788224563159044_kxiqkv.png" },
  { id: "fixed_066", name: "Alien", class: "Beast", affinity: "Cosmic", power_cost: 4, stats: { atack: 6, defense: 2 }, abilities: { on_attack: "Probe", on_defense: "Tech" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624586/Hailuo_image_468788194938806278_ktcmsu.png" },
  { id: "fixed_067", name: "Robot", class: "Dwarf", affinity: "Electric", power_cost: 3, stats: { atack: 4, defense: 6 }, abilities: { on_attack: "Beep", on_defense: "Boop" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624545/Hailuo_image_468788799874859013_r2gaxn.png" },
  { id: "fixed_068", name: "Jester", class: "Human", affinity: "Standard", power_cost: 1, stats: { atack: 1, defense: 1 }, abilities: { on_attack: "Joke", on_defense: "Trick" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624544/Hailuo_image_468788441278664711_xspccj.png" },
  { id: "fixed_069", name: "King", class: "Human", affinity: "Standard", power_cost: 1, stats: { atack: 1, defense: 5 }, abilities: { on_attack: "Order", on_defense: "Guard" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624544/Hailuo_image_468789078611533827_o2u3m2.jpg" },
  { id: "fixed_070", name: "Queen", class: "Human", affinity: "Standard", power_cost: 5, stats: { atack: 8, defense: 2 }, abilities: { on_attack: "Check", on_defense: "Mate" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624544/Hailuo_image_468789106231042054_l7jrmc.png" },
  { id: "fixed_071", name: "Princess", class: "Human", affinity: "Light", power_cost: 2, stats: { atack: 1, defense: 3 }, abilities: { on_attack: "Charm", on_defense: "Help" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624544/Hailuo_image_468789175109861385_o9hhbm.jpg" },
  { id: "fixed_072", name: "Prince", class: "Human / Knight", affinity: "Standard", power_cost: 3, stats: { atack: 4, defense: 3 }, abilities: { on_attack: "Sword", on_defense: "Shield" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768624543/Hailuo_image_468789226917879817_uiolnc.jpg" },
  { id: "fixed_073", name: "Fairy", class: "Elf", affinity: "Nature", power_cost: 1, stats: { atack: 1, defense: 1 }, abilities: { on_attack: "Dust", on_defense: "Fly" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623867/midartai-1768622645916_h0xtea.png" },
  { id: "fixed_074", name: "Goblin", class: "Orc / Warrior", affinity: "Toxic", power_cost: 1, stats: { atack: 2, defense: 1 }, abilities: { on_attack: "Stab", on_defense: "Run" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623831/Hailuo_image_468786943190708231_kwwska.png" },
  { id: "fixed_075", name: "Imp", class: "Mage", affinity: "Fire", power_cost: 1, stats: { atack: 2, defense: 1 }, abilities: { on_attack: "Burn", on_defense: "Hide" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623831/Hailuo_image_468787187399843846_heog9n.png" },
  { id: "fixed_076", name: "Slime", class: "Beast", affinity: "Toxic", power_cost: 1, stats: { atack: 1, defense: 4 }, abilities: { on_attack: "Goo", on_defense: "Split" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623830/Hailuo_image_468786668803538948_y5papp.png" },
  { id: "fixed_077", name: "Bat", class: "Beast", affinity: "Dark", power_cost: 1, stats: { atack: 2, defense: 0 }, abilities: { on_attack: "Bite", on_defense: "Fly" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623830/Hailuo_image_468786640651317258_uqvrwf.png" },
  { id: "fixed_078", name: "Rat", class: "Beast", affinity: "Standard", power_cost: 1, stats: { atack: 1, defense: 0 }, abilities: { on_attack: "Bite", on_defense: "Run" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623829/Hailuo_image_468786336803418122_hphtx4.png" },
  { id: "fixed_079", name: "Spider", class: "Beast", affinity: "Toxic", power_cost: 2, stats: { atack: 3, defense: 2 }, abilities: { on_attack: "Bite", on_defense: "Web" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623829/Hailuo_image_468786397054529539_msoawe.png" },
  { id: "fixed_080", name: "Snake", class: "Beast", affinity: "Toxic", power_cost: 2, stats: { atack: 4, defense: 1 }, abilities: { on_attack: "Bite", on_defense: "Coil" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623829/Hailuo_image_468786566395404290_vmcdzd.png" },
  { id: "fixed_081", name: "Wolf", class: "Beast", affinity: "Nature", power_cost: 2, stats: { atack: 4, defense: 2 }, abilities: { on_attack: "Bite", on_defense: "Pack" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623828/Hailuo_image_468786310823890948_osf8vx.png" },
  { id: "fixed_082", name: "Bear", class: "Beast", affinity: "Earth", power_cost: 3, stats: { atack: 5, defense: 5 }, abilities: { on_attack: "Maul", on_defense: "Fur" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623825/Hailuo_image_468785969155837958_yelibj.png" },
  { id: "fixed_083", name: "Boar", class: "Beast", affinity: "Earth", power_cost: 2, stats: { atack: 4, defense: 3 }, abilities: { on_attack: "Tusk", on_defense: "Hide" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623824/Hailuo_image_468784890229882881_btjqtk.png" },
  { id: "fixed_084", name: "Eagle", class: "Beast", affinity: "Wind", power_cost: 2, stats: { atack: 3, defense: 1 }, abilities: { on_attack: "Claw", on_defense: "Fly" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623824/Hailuo_image_468785673579102209_ewzyro.png" },
  { id: "fixed_085", name: "Owl", class: "Beast", affinity: "Wind", power_cost: 1, stats: { atack: 2, defense: 2 }, abilities: { on_attack: "Peck", on_defense: "See" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623824/Hailuo_image_468785737013723137_c2twol.png" },
  { id: "fixed_086", name: "Cat", class: "Beast", affinity: "Standard", power_cost: 1, stats: { atack: 2, defense: 1 }, abilities: { on_attack: "Scratch", on_defense: "Purr" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623824/Hailuo_image_468785544843325449_vjjuc8.png" },
  { id: "fixed_087", name: "Dog", class: "Beast", affinity: "Standard", power_cost: 1, stats: { atack: 2, defense: 2 }, abilities: { on_attack: "Bite", on_defense: "Bark" }, image_url: "https://res.cloudinary.com/dokkkdftz/image/upload/v1768623823/Hailuo_image_468784831920701442_ycgcma.png" }
];

export const INITIAL_DECK = []; 

export const INITIAL_LOCATIONS: LocationState[] = [
  {
    id: 'loc_1',
    name: 'Ruins of Eldoria',
    description: 'Ancient stones whisper power.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768619934/Hailuo_image_468771070874820609_q6hl7n.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_2',
    name: 'Crystal Caverns',
    description: 'Reflections confuse the weak.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768620063/Hailuo_image_468771566167543815_cohr20.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_3',
    name: 'Iron Forge',
    description: 'Heat strengthens the brave.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768620111/Hailuo_image_468771710329970688_b7kyle.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_4',
    name: 'Molten Crag',
    description: 'The floor is literally lava.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704638/Hailuo_image_469125909320478724_eenycr.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_5',
    name: 'Whispering Woods',
    description: 'Silence is your only ally.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704638/Hailuo_image_469125424240820227_tikrbx.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_6',
    name: 'Starhaven Citadel',
    description: 'Technology lost to time.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704638/Hailuo_image_469125790999097353_w0baxm.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_7',
    name: 'Vampire\'s Keep',
    description: 'Blood runs cold here.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704638/Hailuo_image_469125400391950339_utrguf.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_8',
    name: 'Frostbite Peak',
    description: 'Cold steel, colder hearts.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704638/Hailuo_image_469125373997264903_kbvuwx.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_9',
    name: 'Sunken Sands',
    description: 'Buried secrets await.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704638/Hailuo_image_469125088943980552_ottl2e.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_10',
    name: 'Abyssal Trench',
    description: 'Pressure crushing down.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704638/Hailuo_image_469125253352235017_miwfoi.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  },
  {
    id: 'loc_11',
    name: 'Cloud Sanctuary',
    description: 'Don\'t look down.',
    imageUrl: 'https://res.cloudinary.com/dokkkdftz/image/upload/v1768704637/Hailuo_image_469125116731191302_amchrt.jpg',
    playerCards: [],
    opponentCards: [],
    playerScore: 0,
    opponentScore: 0,
  }
];
