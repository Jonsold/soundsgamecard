
// --- WEB AUDIO API SERVICE ---
// Usando AudioContext para maior compatibilidade e performance em jogos

export const SOUND_MAP: Record<string, string> = {
    // --- MÚSICA DE FUNDO ---
    INTRO:            '/assets/sounds/intro.ogg',
    THEME_DECK:       '/assets/sounds/deck_theme.ogg',
    THEME_BATTLE:     '/assets/sounds/battle_theme.ogg',
    // Removed THEME_BATTLE_02 as requested

    // --- INTERFACE (UI) ---
    UI_CLICK: '/assets/sounds/ui_click.ogg',       
    UI_HOVER: '/assets/sounds/ui_hover.ogg',       
    ERROR:    '/assets/sounds/error.ogg',       
    COINS:    '/assets/sounds/coins.ogg',        

    // --- CARTAS (GAMEPLAY) ---
    CARD_SELECT:       '/assets/sounds/card_select.ogg', 
    CARD_PLAY_ATACK:   '/assets/sounds/attack.ogg', 
    CARD_PLAY_DEFENSE: '/assets/sounds/defense.ogg', 

    // --- EVENTOS DE JOGO ---
    BATTLE_START: '/assets/sounds/battle_start.ogg', 
    VICTORY:      '/assets/sounds/victory.ogg',      
    DEFEAT:       '/assets/sounds/defeat.ogg',       
};

// --- MAPA DE VOZES LOCAIS ---
export const VOICE_COLLECTION = {
    START: [
        '/assets/sounds/voices/start_01.ogg',
        '/assets/sounds/voices/start_02.ogg',
        '/assets/sounds/voices/start_03.ogg',
    ],
    COMMENTARY: [
        '/assets/sounds/voices/comm_01.ogg',
        '/assets/sounds/voices/comm_02.ogg',
        '/assets/sounds/voices/comm_03.ogg',
        '/assets/sounds/voices/comm_04.ogg',
        '/assets/sounds/voices/comm_05.ogg',
        '/assets/sounds/voices/comm_06.ogg',
    ],
    VICTORY: [
        '/assets/sounds/voices/win_01.ogg',
        '/assets/sounds/voices/win_02.ogg',
    ],
    DEFEAT: [
        '/assets/sounds/voices/lose_01.ogg',
        '/assets/sounds/voices/lose_02.ogg',
    ]
};

export type SoundKey = keyof typeof SOUND_MAP;
export type VoiceCategory = keyof typeof VOICE_COLLECTION;

// --- AUDIO ENGINE ---

let audioCtx: AudioContext | null = null;
const bufferCache: Record<string, AudioBuffer> = {};

let currentMusicSource: AudioBufferSourceNode | null = null;
let currentMusicGain: GainNode | null = null;
let currentMusicKey: string | null = null; // Rastreia qual música está tocando atualmente
let targetMusicKey: string | null = null;  // Rastreia qual música *deveria* estar tocando (Intent)

function getAudioContext(): AudioContext {
    if (!audioCtx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        audioCtx = new AudioContextClass();
    }
    return audioCtx;
}

async function loadBuffer(url: string): Promise<AudioBuffer | null> {
    if (bufferCache[url]) return bufferCache[url];

    try {
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }

        const arrayBuffer = await response.arrayBuffer();
        const ctx = getAudioContext();
        const decodedBuffer = await ctx.decodeAudioData(arrayBuffer);
        
        bufferCache[url] = decodedBuffer;
        return decodedBuffer;

    } catch (error) {
        // console.warn(`[AudioService] Warning loading: ${url}`);
        return null;
    }
}

// --- TOCA EFEITOS SONOROS (SFX) ---
export const playSound = async (key: SoundKey, volume: number = 0.5) => {
    // Redireciona músicas para a função correta
    if (key === 'INTRO' || key === 'THEME_DECK' || key === 'THEME_BATTLE') {
        playBackgroundMusic(key, 0.15);
        return;
    }

    const path = SOUND_MAP[key];
    if (!path) return;

    try {
        const ctx = getAudioContext();
        if (ctx.state === 'suspended') await ctx.resume();

        const buffer = await loadBuffer(path);
        if (!buffer) return;

        const source = ctx.createBufferSource();
        source.buffer = buffer;

        const gainNode = ctx.createGain();
        
        // --- MIXAGEM DE ÁUDIO ---
        let finalVolume = volume;
        if (key === 'CARD_PLAY_ATACK' || key === 'CARD_PLAY_DEFENSE') {
            finalVolume = volume * 0.4;
        }
        
        gainNode.gain.value = finalVolume;

        if (['UI_CLICK', 'CARD_SELECT', 'UI_HOVER', 'COINS'].includes(key)) {
            source.playbackRate.value = 0.95 + Math.random() * 0.15;
        }

        source.connect(gainNode);
        gainNode.connect(ctx.destination);
        source.start(0);

    } catch (e) {
        console.error("[AudioService] Erro no playback:", e);
    }
};

// --- TOCA ARQUIVO ESPECÍFICO (PARA TESTES ADMIN) ---
export const playAudioFile = async (url: string, volume: number = 1.0) => {
    try {
        const ctx = getAudioContext();
        if (ctx.state === 'suspended') await ctx.resume();

        const buffer = await loadBuffer(url);
        if (!buffer) return;

        const source = ctx.createBufferSource();
        source.buffer = buffer;

        const gainNode = ctx.createGain();
        gainNode.gain.value = volume;

        source.connect(gainNode);
        gainNode.connect(ctx.destination);
        source.start(0);
    } catch (e) {
        console.error("[AudioService] Play File Error:", e);
    }
};

// --- TOCA VOZ ALEATÓRIA ---
export const playRandomVoice = async (category: VoiceCategory, volume: number = 1.0) => {
    const options = VOICE_COLLECTION[category];
    if (!options || options.length === 0) return;
    const randomFile = options[Math.floor(Math.random() * options.length)];
    playAudioFile(randomFile, volume);
};

// --- GESTÃO DE MÚSICA DE FUNDO (SISTEMA CORRIGIDO) ---

// Função interna para parar o nó de áudio atual sem resetar a intenção global
const stopCurrentNode = () => {
    if (currentMusicSource) {
        try {
            currentMusicSource.stop();
            currentMusicSource.disconnect();
        } catch (e) { }
        currentMusicSource = null;
    }
    if (currentMusicGain) {
        try {
            currentMusicGain.disconnect();
        } catch (e) {}
        currentMusicGain = null;
    }
    currentMusicKey = null;
};

export const playBackgroundMusic = async (key: SoundKey, volume: number = 0.15) => {
    const path = SOUND_MAP[key];
    if (!path) return;

    // 1. Define a INTENÇÃO global. Isso é crucial para evitar race conditions.
    // "Eu quero que a música 'key' toque."
    targetMusicKey = key;

    // 2. Se a música pedida já está tocando, não faz nada.
    if (currentMusicKey === key && currentMusicSource) return;

    // 3. Para qualquer música que esteja tocando agora.
    stopCurrentNode();

    try {
        const ctx = getAudioContext();
        if (ctx.state === 'suspended') await ctx.resume();

        // 4. Carrega o buffer (isso leva tempo).
        const buffer = await loadBuffer(path);

        // 5. CHEQUE DE SEGURANÇA (RACE CONDITION FIX):
        // Enquanto o buffer carregava, o usuário pode ter mudado de tela novamente.
        // Verificamos: "A música que eu acabei de carregar ainda é a que o usuário quer ouvir?"
        if (targetMusicKey !== key) {
             // Se não for, abortamos silenciosamente. Não tocamos essa música antiga.
             return; 
        }

        // 6. Garante que nada está tocando (caso outro load paralelo tenha terminado milissegundos antes)
        stopCurrentNode();

        if (!buffer) return;

        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.loop = true;

        const gainNode = ctx.createGain();
        gainNode.gain.value = volume; 

        source.connect(gainNode);
        gainNode.connect(ctx.destination);
        source.start(0);

        currentMusicSource = source;
        currentMusicGain = gainNode;
        currentMusicKey = key;

    } catch (e) {
        console.error("[AudioService] Erro música:", e);
    }
};

export const stopBackgroundMusic = () => {
    // Quando chamamos stop explicitamente, resetamos a intenção.
    targetMusicKey = null; 
    stopCurrentNode();
};
