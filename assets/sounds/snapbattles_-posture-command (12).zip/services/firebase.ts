
import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import "firebase/compat/analytics";

/**
 * FIREBASE CONFIGURATION
 */
const firebaseConfig = {
  apiKey: "AIzaSyAb9-xtzpjDVc94q587Yb26jxdxX_Fbc5A",
  authDomain: "game-card-snap.firebaseapp.com",
  projectId: "game-card-snap",
  storageBucket: "game-card-snap.firebasestorage.app",
  messagingSenderId: "206982420068",
  appId: "1:206982420068:web:c17ca32965c5b15b3ff171",
  measurementId: "G-6WQJPEBP09"
};

// Initialize Firebase App only once
let app;
if (!firebase.apps.length) {
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app(); // Use existing instance if available
}

// Explicitly pass the app instance to service initializers
export const auth = firebase.auth();
export const db = firebase.firestore(); 
export const analytics = firebase.analytics();
export const googleProvider = new firebase.auth.GoogleAuthProvider();

// Configure persistence using compat method to avoid module import errors
db.enablePersistence({ synchronizeTabs: true })
  .catch((err) => {
      if (err.code === 'failed-precondition') {
          console.warn("Multiple tabs open, persistence can only be enabled in one tab at a a time.");
      } else if (err.code === 'unimplemented') {
          console.warn("The current browser does not support all of the features required to enable persistence");
      }
  });

console.log("✅ [Firebase] Nexus estabelecido e serviços registrados.");
