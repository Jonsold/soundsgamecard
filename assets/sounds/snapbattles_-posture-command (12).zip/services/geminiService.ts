
import { LocationState } from '../types';

// --- LOCAL NARRATIVE DATABASE ---
// No longer using external AI. These phrases provide instant context updates.

const OPENING_PHRASES = [
    "The armies deploy for battle!",
    "First blood will decide the momentum.",
    "The calm before the storm...",
    "Positioning is key in the early stages.",
    "The initial clash begins!",
    "Banners fly high, ready for war."
];

const GENERIC_PHRASES = [
    "The battlefield trembles underfoot.",
    "Steel clashes against steel!",
    "Magic energy saturates the air.",
    "A calculated move.",
    "The tension is palpable.",
    "No quarter given, none asked.",
    "Forces collide with brutal impact.",
    "A strategic display of power."
];

const WINNING_PHRASES = [
    "You have the upper hand!",
    "The enemy formation is breaking!",
    "Press the advantage now!",
    "Victory is within reach!",
    "Their defenses are crumbling.",
    "A dominating performance!"
];

const LOSING_PHRASES = [
    "The enemy is overwhelming us!",
    "Hold the line! We are losing ground!",
    "We need a miracle to turn this.",
    "Defenses are failing!",
    "The situation is dire.",
    "Enemy forces are advancing rapidly."
];

const CLOSE_MATCH_PHRASES = [
    "It's a dead heat!",
    "Neither side gives an inch.",
    "A balanced struggle for dominance.",
    "The scales of war are even.",
    "Every point matters now.",
    "A fierce stalemate!"
];

interface CommentaryResult {
    text: string;
}

/**
 * Generates a battle commentary string based on the current game state strictly locally.
 * Replaces the previous Gemini AI implementation.
 */
export const generateBattleCommentary = async (
    turnNumber: number,
    location: LocationState
): Promise<CommentaryResult> => {
    
    let options = GENERIC_PHRASES;

    // 1. Game Stage Logic
    if (turnNumber <= 1) {
        options = OPENING_PHRASES;
    } 
    else {
        // 2. Score Context Logic
        const diff = location.playerScore - location.opponentScore;

        if (Math.abs(diff) <= 5) {
            // Close match: Mix generic with tension phrases
            options = [...GENERIC_PHRASES, ...CLOSE_MATCH_PHRASES];
        } else if (diff > 5) {
            // Player winning significantly
            options = WINNING_PHRASES;
        } else if (diff < -5) {
            // Player losing significantly
            options = LOSING_PHRASES;
        }
    }

    // Pick a random phrase from the determined context
    const text = options[Math.floor(Math.random() * options.length)];
    
    // Returns a Promise to maintain compatibility with existing BattleScreen logic
    return { text };
};
