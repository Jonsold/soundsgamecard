
export type CardClass = 
  | 'Elf' 
  | 'Dwarf' 
  | 'Human / Knight' 
  | 'Orc / Warrior' 
  | 'Mage' 
  | 'Beast' 
  | 'Undead'
  | 'Warrior'
  | 'Human'
  | 'Human Warrior'
  | 'Monster Warrior'
  | 'Dragon'
  | 'Zombie';

export type CardAffinity = 
  | 'Standard' 
  | 'Fire' 
  | 'Ice' 
  | 'Nature' 
  | 'Dark' 
  | 'Light' 
  | 'Earth' 
  | 'Wind' 
  | 'Electric' 
  | 'Toxic' 
  | 'Cosmic'
  | 'Aquatic';

export type PlayerRank = 
  | 'Aliado'        // Nivel 1
  | 'Comandante'    // Nivel 2
  | 'Campeão'       // Nivel 3
  | 'General'       // Nivel 4
  | 'Rei'           // Nivel 5
  | 'Rei Supremo';  // Nivel 6

export interface CardStats {
  atack: number;
  defense: number;
}

export interface CardAbilities {
  on_attack: string;
  on_defense: string;
}

export interface CardData {
  id: string;
  name: string;
  class: CardClass;
  affinity?: CardAffinity; // New field for elemental type/color
  power_cost: number;
  stats: CardStats;
  abilities: CardAbilities;
  image_url: string;
}

export type Posture = 'ATACK' | 'DEFENSE';

export interface PlayedCard extends CardData {
  instanceId: string;
  owner: 'player' | 'opponent';
  mode: Posture;
  revealed: boolean;
}

export interface LocationState {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  playerCards: PlayedCard[];
  opponentCards: PlayedCard[];
  playerScore: number;
  opponentScore: number;
}

export type GamePhase = 'PLANNING' | 'RESOLVING' | 'CELEBRATION' | 'GAME_OVER';

export type AppView = 'LOGIN' | 'HOME' | 'DECK_BUILDER' | 'BATTLE' | 'ADMIN' | 'SHOP';

export interface UserProfile {
  id: string;
  name: string; // Character Name
  avatarId: string; // Chosen Avatar ID
  mainAffinity: CardAffinity; // Chosen Emblem/Type
  passwordHash: string; // Simulated hash
  level: number; // Determines Rank
  wins: number;
  losses: number;
  points: number; // Currency
  collection: string[];
  currentDeck: string[];
}
